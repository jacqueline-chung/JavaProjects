import java.util.Scanner;

class ArrayTest {
  
  static Scanner myScanner = new Scanner(System.in);//declare scanner class as a global variable
  
  public static void main (String args[]) {
    
    Scanner myScanner = new Scanner (System.in);
    
    int [] integers = new int [10];
    int response = 0;
    
    enterFromKeyboard(integers);
    while (response != 12) {
      System.out.println("Choose a method: 1) countWhole 2) display 3) displayReverse 4) sum  5) average  6) findMax/findMin  7)Search ");
      response = myScanner.nextInt();
      
      if (response == 1) {
        countWhole(integers);
      } else if (response == 2) {
        display(integers);
      } else if (response == 3) {
        displayReverse(integers);
      } else if (response == 4) {
        sum(integers);
      } else if (response == 5) {
        average(integers);
      } else if (response == 6) {
        findMax(integers);
        findMin(integers);
      } else if (response == 7) {
        search(integers);
      } else if (response == 8) {
        bubbleSort(integers);
      } else if (response == 12) {
        break;
      }
    }
    System.out.println ("Thanks for choosing! Bye!");
  }
  
  public static int[] enterFromKeyboard (int array[]) {
    
    System.out.println("Enter 10 integers: ");
    
    for (int i = 0; i < array.length; i++) {
      array[i] = myScanner.nextInt();
    }
    
    return array;
  }
  
  public static int[] countWhole (int array[]) {
    
    int counter = 0;
    
    for (int i = 0; i < array.length; i++) {
      if (array[i] > 0) {
        counter++;
      }
    }
    System.out.println("The number of whole numbers are " + counter);
    
    return array;
  }
  
  public static int[] display (int array[]) {
    
    for (int i = 0; i < array.length; i++) {
      System.out.println(array[i]);
    }
    
    return array;
  }
  
  public static int[] displayReverse (int array[]) {
    
    for (int i = (array.length - 1); i >= 0; i--) {
      System.out.println(array[i]);
    }
    
    return array;
  }
  
  public static int[] sum (int array[]) {
    
    int sum = 0;
    
    for (int i = 0; i < array.length; i++) {
      sum += array[i];
    }
    
    System.out.println("The sum of the array is " + sum);
    
    return array;
  }
  
  public static int[] average (int array[]) {
    
    int average, sum = 0;
    
    for (int i = 0; i < array.length; i++) {
      sum += array[i];
    }
    
    average = sum / array.length;
    
    System.out.println("The average of the array is " + average);
    
    return array;
  }
  
  public static int[] findMax (int array[]) {
    
    int max = array[1];
    int counter = 0;
    
    for (int i = 0; i < array.length; i++) {
      if (array[i] > max) {
        max = array[i];
        counter = 1;
      } else if(array[i]==max) {
        counter++;
      }
    }
    
    System.out.print("The max of the array is " + max + " and it occurs " + counter + " time(s)");
    
    return array;
  }
  
  public static int[] findMin (int array[]) {
    
    int min = array[1];
    int counter = 0;
    
    for (int i = 0; i < array.length; i++) {
      if (array[i] < min) {
        min = array[i];
        counter = 1;
      } else if(array[i]==min) {
        counter++;
      }
    }
    
    System.out.print("\nThe min of the array is " + min + " and it occurs " + counter + " time(s)");
    
    return array;
  }
  
  public static int[] search (int array[]) {
    
    int searchNum;
    Boolean found = false;
    
    System.out.println ("Enter the integer you want found: ");
    searchNum = myScanner.nextInt();
    
    System.out.println ("The integer was not found in index ");
    for (int i = 0; i < array.length; i++) {
      if (searchNum == array[i]) {
        System.out.println (i + " ");
        found = true;
      }
    }
    
    if (found = false) {
      System.out.println ("The integer was not found.");
    }
    
    return array;
  }
  
  public static int[] bubbleSort (int array[]) {
    
    int temp = 0, j = 0;
    
    j = j + 1;
    
    for (int i = 0; i < array.length; i++) {
      if (array[i] < array [i-1]) {
        temp = array[i];
        array[i] = array[i-1];
        array[i-1] = temp;
      }
    }
    
    for (int i = 0; i < array.length; i++) {
      System.out.print("\nSorted array is " + array[i]);
    }
    
    return array;
  }
}