/*
 * Array Exercises (Level 2)
 * [Array2.java]
 * Author: Duffy Du
 * Sept 16, 2015
 */

import java.util.Scanner;

class Array2a{
  public static void main(String args[]){
    
    Scanner input = new Scanner(System.in);
    
    int integerArray[] = new int[10];
    int menuChoice;
    
    initializeArray(integerArray);
    enterFromKeyboard(integerArray);
    
    do {
      
      System.out.println("Welcome, take a look at the menu");
      System.out.println("1. Initialize Array");
      System.out.println("2. Enter From Keyboard");
      System.out.println("3. Count Whole");
      System.out.println("4. Display");
      System.out.println("5. Display Reverse");
      System.out.println("6. Average");
      System.out.println("7. Find Max");
      System.out.println("8. Find min"); 
      System.out.println("9. Search");
      System.out.println("10. Exit");
      
      System.out.println("Please enter your choice (1-10): ");
      menuChoice = input.nextInt();
      
      if (menuChoice == 1){
        //1
        initializeArray(integerArray);
        
      } else if (menuChoice == 2){
        //2
        enterFromKeyboard(integerArray);
      } else if (menuChoice == 3){
        //4
        countWhole(integerArray);
      } else if (menuChoice == 4){
        //5
        display(integerArray);
      } else if (menuChoice == 5){
        //6
        displayReverse(integerArray);
      } else if (menuChoice == 6){
        average(integerArray);
      } else if (menuChoice == 7){
        findMax(integerArray);
      } else if (menuChoice == 8){
        findMin(integerArray);
      } else if (menuChoice == 9){
        search(integerArray);
      }    
    } while (menuChoice !=10);
    
    
  }
  
  //******************InitializeArray() method********************
  public static void initializeArray(int[] array){
    
    System.out.println("Running InitializeArray...");
    
    for (int i=0; i<array.length;i++){
      array[i] = -1;
      //System.out.println(array[i]);
    }
    
    
  }
  
  //*****************enterFromKeyboard() method********************
  public static void enterFromKeyboard(int[] array){
    
    System.out.println("Running EnterFromKeyboard...");
    
    Scanner input = new Scanner(System.in);
    /*
    int numberOfInt; 
    
    System.out.println("How many integers are you going to enter? (1-10)");
    numberOfInt = input.nextInt();
    */
    for (int i=0; i<array.length;i++){
      array[i] = input.nextInt();
      //System.out.println(array[i]);
    }
  }
  
  //******************CountWhole() method***************************
  public static void countWhole(int[] array){
    
    System.out.println("Running CountWhole...");
    
    int counter = 0;
    
    for (int i=0; i<array.length;i++){
      if (array[i]>=0){
        counter++;
      }
      
    }
    System.out.println("There is/are " + counter + " whole numbers in the array.");
    
  }
  
  //***************Display() method*****************************
  public static void display(int[] array){
    
    System.out.println("Running Display...");
    
    System.out.print("The integers in order entered is ");
    for (int i=0; i<10; i++){
      System.out.print(array[i] + " ");
      
    }
    
    System.out.println(" ");
    
  }
  
  //****************Display Reverse() method************************
  public static void displayReverse(int[] array){
    
    System.out.println("Running DisplayReverse...");
    
    System.out.print("The integers in reverse order entered is ");
    for (int i=9; i>=0; i--){
      System.out.print(array[i] + " ");
      
    }
    System.out.println();
    
  }
  
  //*******************Sum() method********************************
  public static int sum(int[] array){
       
    System.out.println("Running Sum...");
    
    int sum=0;
    
    for (int i=0; i<10; i++){
      sum= sum + array[i];
    }
    
    System.out.println("The sum of all the numbers entered = " + sum);
    return sum;
    
  }
  
  //****************** Average() method *********************
  public static void average(int[] array){
    
    System.out.println("Running Average...");
    int sum;
    double average;
    
    sum = sum(array);
    average = sum /10;
    
    System.out.println("The average is " + average);
    
  }
  
  //********************* FindMax() method ******************
  public static void findMax(int[] array){
    
    System.out.println("Running FindMax...");
    int max = array[0];
    int occurrences = 0;
    
    for (int i = 1; i<array.length; i++){
      if  (array[i]>max){
        
        max = array[i];
        occurrences = 1;
      } else if(array[i]==max){
        
        //System.out.println("occurrence index "+ i);
        occurrences++;
      }
    }
    
    System.out.println("The maximum number is " + max);
    System.out.println("# of occurrences " + occurrences);
    
  }
  
  
  //*********************** FindMin() method ******************
  public static void findMin (int[] array){
    
    System.out.println("Running FindMin...");
    int min = array[0];
    int occurrences = 0;
    
    for (int i = 1; i<array.length; i++){
      if  (array[i]<min){
        
        min = array[i];
        occurrences = 1;  // reset the number of occurences
      }else if(array[i]==min){
        
        //System.out.println("occurrence index "+ i);
        occurrences++;
      }
    }
    
    System.out.println("The minimum number is " + min);
    System.out.println("# of occurrences " + occurrences);
  }
  
  //********************* Search method **********************
  public static void search (int[] array){
    
    System.out.println("Running Search...");
    
    Scanner input = new Scanner(System.in);
    
    int num;
    Boolean valid = false;
    System.out.println("Please enter the number you would like to search for: ");
    num = input.nextInt();
    
    System.out.println("The number " + num +  " is found in the following positions...");
        
    for (int i = 0; i<array.length; i++){
      if(array[i] == num){
        System.out.print(i + " ");
        valid = true;
      } 
    }
    
    if (valid ==false ){
       System.out.println("The number " + num + " is not found in the array"); 
      }
    System.out.println(" ");
  }
  
}
    