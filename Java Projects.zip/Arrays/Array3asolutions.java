import java.util.Random;
import java.util.Scanner;

public class Array3asolutions
{
  static Scanner input = new Scanner(System.in);
  public static void main(String[] args) {
    int userInput = 5;
    
    if (userInput == 1) {
      noDuplicates();
    } else if (userInput == 2) {
      randomNoDuplicates();
    } else if (userInput == 3) {
      enterAndCount();
    } else if (userInput == 4) {
      randomOrder();
    } else if (userInput == 5) {
      threeRandomOrder();
    }
    
  }
  
  /**
   * Method to print the contents of an array called list.
   */
  public static void printList(int[] list) {
    for(int k=0; k<list.length; k++) {
      System.out.print(list[k] + " ");
    }
    System.out.println();
  }
  
  /**
   * Method to check for a duplicate number in the elements of the list
   * that come before the index indicated.
   */
  public static boolean isDuplicate(int[] list, int num, int index) {
    boolean duplicate = false;
    for (int i=0; i < index; i++) {
      if (list[i] == num) {
        duplicate = true;
      }
    }
    return duplicate;
  }
  
  /**
   * Method asks the user to enter unique numbers and ensures that
   * no duplicates have been entered.
   */
  public static void noDuplicates() {
    int[] list = new int[7];
    int num;
    for (int i = 0; i < list.length; i++) {
      System.out.println("Please enter a unique number");
      num = input.nextInt();
      while (isDuplicate(list, num, i) ){
        System.out.println("Please try again, number exists");
        num = input.nextInt();
      }
      list[i] = num; // store the value in the array     
    }
    // print the values in the array
    printList(list); 
  }
  
  /**
   * Method to populate the array (list) with random numbers within the range
   * specified.  No duplicates will be stored in the list.
   */
  public static void populateRandomListNoDuplicates(int[] list, int start, int end) {
    Random random = new Random();
    int randomNumber;
    
    for (int i = 0; i < list.length; i++) {
      randomNumber = random.nextInt(end-start)+start;
      while (isDuplicate(list, randomNumber, i) ){
        randomNumber = random.nextInt(end-start)+start;
      }
      list[i] = randomNumber; // store the value in the array    
    }
  }
  
  /**
   * Generates and prints a list of random numbers from 0 to 9 inclusive.
   */
  public static void randomNoDuplicates(){
    int[] list = new int[10];
    populateRandomListNoDuplicates(list, 0, 10);
    printList(list);
  }
  
  /**
   * File IO question, to be updated soon.
   */
  public static void enterAndCount() {
  }
  
  /**
   * Method that creates a list of divers and prints them in a random order.
   */
  public static void randomOrder() {
    String[] divers = {"Jen", "Cathy", "Ben", "Carl", "Emma"};
    int[] randomOrder = new int[divers.length];
    populateRandomListNoDuplicates(randomOrder, 0, 5);
    
    for (int i = 0; i < divers.length; i++) {
      System.out.println(divers[randomOrder[i]]);
    }
  }
  
  /**
   * Method prints the list of diver 3 times.  Each time in a random order.
   */
  public static void threeRandomOrder() {
    for (int i= 0; i < 3; i++) {
      System.out.println("Random Order: " + (i+1));
      randomOrder();
    }
  }
}
