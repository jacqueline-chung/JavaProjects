/*Name: Jacqueline Chung
 * File: Recursion4
 * Teacher: Agreghetti
 * Date: October 15, 2015
*/
import java.util.Scanner;

public class Recursion4 {
  public static void main (String args[]) {
   
    Scanner myScanner = new Scanner(System.in);
   
    System.out.println("Enter a number of laughs");
    int numLaugh = myScanner.nextInt();
   
    System.out.println(laugh(numLaugh));
  }
  
  public static String laugh(int n) {
   
    if(n == 0) {
       return "No laugh";
    } else {
      return laugh(n); 
//      return laugh("HA", n); 
    }
  }
  
}