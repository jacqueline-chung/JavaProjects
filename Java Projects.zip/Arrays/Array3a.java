/* [Array3a.java]
 * Create a menu driven program that will run any procedure described below. Use only local variables.
 * Author: Jacqueline Chung
 * Date: September 16, 2015
 */

import java.util.Scanner;
import java.util.Random;
import java.io.PrintWriter;
import java.io.File;
import java.io.*;

public class Array3a {
  public static void main(String args[]) throws Exception {  //main method
    
    Scanner userInput = new Scanner(System.in);//declare scanner
    //declare variables
    int[] array = new int[100];
    
    int r = 0;
    
    //Add a loop so that the user can make other choices from the menu for the numbers that the user entered.
    
    while (r != 6) { //loop while the response isn't 6
      System.out.println("Enter the procedure. 1) noDuplicates 2) randomNoDuplicates 3) enterAndCount 4) randomOrder 5) threeRandomOrder "); //prompt user for the options
      r = userInput.nextInt();//store input
      
      //call methods according to number inputted
      if (r == 1) {
        noDuplicates(array);
      } else if (r == 2) {
        randomNoDuplicates(array);
      } else if (r == 3) {
        enterAndCount(array);
      } else if (r == 4) {
        randomOrder(array);
      } else if (r == 5) {
        threeRandomOrder(array);
      } else if (r == 6) {
        break;
      }
    }
    System.out.println("Thanks!"); //output message after loop is done
  } 
  
  //Create a procedure called noDuplicates which will prompt the user to enter 7 unique integers. 
  //As the user enters the numbers, ask them to re-enter a 5number if it has been entered previously. Output the 7 unique numbers.
  public static int[] noDuplicates(int x[]) { 
    
    Scanner input = new Scanner(System.in);//created a scanner called input
    
    int[] integers = new int[7];//created an array with 7 spots called integers
    boolean duplicate;//created a boolean varibale that stores wether or not the duplicate exists
    
    //prompt the user to enter 7 unique integers
    System.out.println("Please enter 7 unique integers: ");
    for(int i =0; i < 7; i++){
      //save the user input into the array
      integers[i] = input.nextInt();
      
      //----------checking for duplicates---------
      do {
        duplicate = false;//everytime the do while loop loops, set the duplicate variable to false
        
        //for loop to go through each item in the array that is stored before the one user just entered
        for (int c = 0; c < i; c++){
          
          //if one of the item in the array is the same as the one the user just entered
          if (integers[c] == integers[i]){
            
            duplicate = true;//set the duplicate variable to be true, which means there is a duplicate
            
            //print on the screen and ask the user to enter another number
            System.out.println("This number has already been entered, please try another unique number: ");
            integers[i] = input.nextInt();//stores the new number user entered in the same spot in the array
            
            break;//exit the for loop for checking duplicates, so that the next time it checks, it starts from the beginning of the array
          }
        }
      } while (duplicate == true);// if there were a duplicate during the checking process, then it goes through the checking process again to check to new number entered
    }
    
    //outputing the 7 unique numbers
    for (int i=0; i < 7; i++){
      System.out.println(integers[i]);
    }
    
    return x;
    
  }
  
  //Create a procedure called randomNoDuplicates which will output 10 unique integers all which fall within a specified range.
  public static int[] randomNoDuplicates(int x[]) { 
    
    Random r = new Random();
    int[] integers = new int[10];//created an array with 7 spots called integers
    boolean duplicate;//created a boolean varibale that stores wether or not the duplicate exists
    
    for(int i = 0; i < 10; i++){
      //save the user input into the array
      integers[i] = r.nextInt(10);
      
      //----------checking for duplicates---------
      do {
        duplicate = false;//everytime the do while loop loops, set the duplicate variable to false
        
        //for loop to go through each item in the array that is stored before the one user just entered
        for (int c = 0; c < i; c++){
          
          //if one of the item in the array is the same as the one the user just entered
          if (integers[c] == integers[i]){
            
            duplicate = true;//set the duplicate variable to be true, which means there is a duplicate
            integers[i] = r.nextInt(10);//stores the new number user entered in the same spot in the array
            
            break;//exit the for loop for checking duplicates, so that the next time it checks, it starts from the beginning of the array
          }
        }
      } while (duplicate == true);// if there were a duplicate during the checking process, then it goes through the checking process again to check to new number entered
    }
    
    //outputing the 7 unique numbers
    for (int i=0; i < 10; i++){
      System.out.print(integers[i] + " ");
    }
    
    System.out.println();
    
    return x;
  }
  
  //Create a procedure called enterAndCount that will ask the user to enter 4 numbers (allowing no duplicates) from 1 and 100 that they want to look for and count.
  //The program will then open a text file (the user should enter the filename) and count the number of times those numbers appear in the text file. 
  //Output each number and the number of asterisks (*) equal to the number of times that number was found in the text file. 
  //Output the number which had the most asterisks associated with it.
  public static int[] enterAndCount(int x[]) throws Exception { 
    
    Scanner userInput = new Scanner(System.in);
    
    Random r = new Random();
    int[] integers = new int[100];//created an array with 7 spots called integers
    boolean duplicate;//created a boolean varibale that stores wether or not the duplicate exists
    
//    System.out.println("Enter file name for txt file"); 
//    String filename = userInput.nextLine();
    
    File myFile = new java.io.File("enterAndCount.txt");
    PrintWriter output = new PrintWriter(myFile);
    
    for(int i = 0; i < 100; i++){
      //save the user input into the array
      integers[i] = r.nextInt(100);
      output.println(integers[i]); //print all 100 random numbers
    }
    
    System.out.println("Enter 4 numbers from 1 and 100 "); 
    
    for (int i = 0; i < 4; i++) {
      x[i] = userInput.nextInt(); //store input
      
      if (x[i] > 100 || x[i] < 1) {
        System.out.println("That's not within the range. Please enter another number");
        x[i] = userInput.nextInt();
      }
      
      //----------checking for duplicates---------
      do {
        duplicate = false;//everytime the do while loop loops, set the duplicate variable to false
        
        //for loop to go through each item in the array that is stored before the one user just entered
        for (int c = 0; c < i; c++){
          
          //if one of the item in the array is the same as the one the user just entered
          if (x[c] == x[i]){
            duplicate = true;//set the duplicate variable to be true, which means there is a duplicate
            System.out.println("No duplicates! Please enter another number:");
            x[i] = userInput.nextInt();//stores the new number user entered in the same spot in the array
            
            break;//exit the for loop for checking duplicates, so that the next time it checks, it starts from the beginning of the array
          }
        }
      } while (duplicate == true);// if there were a duplicate during the checking process, then it goes through the checking process again to check to new number entered
    }
    
    int [] counter = new int [100];
    
    for (int i = 0; i < 4; i++) {
      counter[i] = 0;
      for (int j = 0; j < 100; j++) {
        if (x[i] == integers[j]) {
          counter[i]++;
        }
      }
    }
    
    for (int i = 0; i < 4; i++) {
      System.out.print(x[i] + ": ");
      for (int j = 0; j < counter[i]; j++) {
        System.out.print("*");
      }
      System.out.println();
    }
    output.close();
    return x;
  }
  
  //Five divers are to compete in a diving competition. Create a procedure called randomOrder which will output the names of these 5 divers in a random diving order.
  public static int[] randomOrder(int x[]) { 
    
    Scanner userInput = new Scanner(System.in);
    
    String[] diverNames = {"Ben", "Joy", "Meg", "Jon", "Mike"};
    Random r = new Random();
    int[] integers = new int[5];//
    boolean duplicate;
    
    for (int i = 0; i < 5; i++) {
      integers[i] = r.nextInt(5); //generate random numbers
      
      //----------checking for duplicates---------
      do {
        duplicate = false;//everytime the do while loop loops, set the duplicate variable to false
        
        //for loop to go through each item in the array that is stored before the one user just entered
        for (int c = 0; c < i; c++){
          
          //if one of the item in the array is the same as the one the user just entered
          if (integers[c] == integers[i]){
            duplicate = true;//set the duplicate variable to be true, which means there is a duplicate
            integers[i] = r.nextInt(5);//stores the new number user entered in the same spot in the array            
            break;//exit the for loop for checking duplicates, so that the next time it checks, it starts from the beginning of the array
          }
        }
      } while (duplicate == true);//
      System.out.println(integers[i]);
    }
    
    for (int i = 0; i < 5; i++) {
      System.out.println(diverNames[integers[i]]);
    }
    
    return x;
  }
  
  //Create a procedure called threeRandomOrder which will output 3 random orders with different divers going first and last each time. There are 5 divers.
  public static int[] threeRandomOrder(int x[]) { 
    
    int[] numbers = new int[5];//
    String[] diverNames = {"Ben", "Joy", "Meg", "Jon", "Mike"};
    
    for (int j = 0; j < 3; j++) {
      numbers = getRandomArray(x); 
    }
    
    for (int i = 0; i < 5; i++) {
      System.out.println(diverNames[numbers[i]]);
    }
    System.out.println();
    
    return x;
  }
  
  public static int[] getRandomArray(int integers[]) { 
    
    Random r = new Random();
    boolean duplicate;
    
    for (int i = 0; i < 5; i++) {
      integers[i] = r.nextInt(5); //generate random numbers
      
      //----------checking for duplicates---------
      do {
        duplicate = false;//everytime the do while loop loops, set the duplicate variable to false
        
        //for loop to go through each item in the array that is stored before the one user just entered
        for (int c = 0; c < i; c++){
          
          //if one of the item in the array is the same as the one the user just entered
          if (integers[c] == integers[i]){
            duplicate = true;//set the duplicate variable to be true, which means there is a duplicate
            integers[i] = r.nextInt(5);//stores the new number user entered in the same spot in the array            
            break;//exit the for loop for checking duplicates, so that the next time it checks, it starts from the beginning of the array
          }
        }
      } while (duplicate == true);//
      System.out.println(integers[i]);
      
      return integers;
    }
  }
}