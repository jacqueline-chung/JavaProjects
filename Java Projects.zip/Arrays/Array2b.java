/* [Array2b.java]
 * Create a menu driven program that will run any procedure described below. Use only local variables.
 * Author: Jacqueline Chung
 * Date: September 16, 2015
 */

import java.util.Scanner;
class Array2b {
  public static void main(String args[]) {  //main method
    
    Scanner userInput = new Scanner(System.in);
    
    int[] array = new int[100];
    int[] wholeArray = new int [100];
    
    int r = 0;
    
    //12. Add a loop so that the user can make other choices from the menu for the numbers that the user entered.
    
    while (r != 5) { //loop while the response isn't 5
      System.out.println("Enter the procedure. 1) Natural Numbers & Occurances 2)# of Occurences Range 15 to 25 3)Sum of Whole Numbers 4) Sum of Whole Numbers (V2) 5) Quit"); //prompt user for the options
      r = userInput.nextInt();//store input
      //call methods according to number inputted
      if (r == 1) {
        countOccurrences(array);
      } else if (r == 2) {
        countOccurrences2(array);
      } else if (r == 3) {
        totals(wholeArray);
      } else if (r == 4) {
        totals(wholeArray);
      }
    }
    System.out.println("Thanks!"); //output message after loop is done
  } 
  //1. Write a procedure called countOccurrences which will prompt the user to enter a natural number from 1 to 10 
  
  //(stop entering numbers when the user enters a number outside the range). The procedure will output the number of the times each number was entered. 
  
  public static int[] countOccurrences(int x[]) { 
    
    Scanner userInput = new Scanner(System.in);
    
    System.out.println("How many natural numbers would you like to enter?");
    int ans = userInput.nextInt();
    
    System.out.println("Please enter " + ans + " numbers: "); 
    
    for (int i = 0; i < ans; i++) {
      
      do {
        x[i] = userInput.nextInt();
      } while (x[i] < 1 && x[i] > 10);
    }
    System.out.println("The integers entered are: ");
    
    for (int i = 0; i < ans; i++) {      
      System.out.print(x[i] + " ");
    }
    System.out.println(" ");
    
    int counter[] = new int[10];
    
    for (int i = 1; i < 11; i++) {      
      for (int j = 0; j < ans; j++) {
        if (x[j] == i) {
          counter[i-1]++;
        }
      }
      System.out.println(i + " :  " + counter[i-1]);
    }
    return x;
  }
  
  ///////////////////////ranges from 15 to 25////////////////////////////////////////////
  
  public static int[] countOccurrences2(int x[]) { 
    
    Scanner userInput = new Scanner(System.in);
    
    System.out.println("How many natural numbers would you like to enter?");
    
    int ans = userInput.nextInt();
    System.out.println("Please enter " + ans + " numbers: ");
    
    for (int i = 0; i < ans; i++) {
      do {
        x[i] = userInput.nextInt();
      } while (x[i] < 15 && x[i] > 25);
    }  
 
    int counter[] = new int[12]; 
    
    for (int i = 15; i < 26; i++) {
      for (int j = 0; j < ans; j++) {
        if (x[j] == i) {
          counter[i-14]++;
        }
      }
      System.out.println(i + " :  " + counter[i-14]);
    }
    return x;
  }
  
  //3. Add a procedure called totals which will prompt the user to enter whole numbers from 0 to 99
  //(stop entering numbers when the entered number is outside the range).  
  //The procedure  will output the total (sum) of all numbers entered less than 10, the total of all numbers entered in the teens (10 to 19), 
  //the total of all numbers entered in the 20s, ... and the total of all numbers entered in the 90s. 
  
  public static int[] totals(int x[]) {
    
    Scanner userInput = new Scanner(System.in);
    
    int sum = 0; //declare array variable
    int[] wholeNumbers = new int[100];
    
    System.out.println("How many numbers would you like to enter?"); //prompt user to enter the number of whole numbers
    int ans = userInput.nextInt(); //store input
    
    System.out.println("Enter whole numbers"); //prompt user to enter the whole numbers
    for (int i = 0; i < ans; i++) { //start for loop to stop when the number is less than the number of whole numbers entered
      do {
        wholeNumbers[i] = userInput.nextInt(); //store whole numbers in array
      } while (x[i] <= 0 && x[i] > 100); //do whle the number is less than and equal to zero and greater than 100
    }
    for (int i = 0; i < ans; i++) {
      if (wholeNumbers[i] < 10) { //if whole number is less than 10
        sum = sum + wholeNumbers[i];
        System.out.println ("The sum in the 10s is " + sum);
      } else if (wholeNumbers[i] < 20 && wholeNumbers[i] > 9) { //if whole number is less than 10
        sum = sum + wholeNumbers[i];
        System.out.println ("The sum in the teens is " + sum);
      } else if (wholeNumbers[i] < 30 && wholeNumbers[i] > 19) { //if whole number in the 20s
        sum = sum + wholeNumbers[i];
        System.out.println ("The sum in the 20s is " + sum);
      } else if (wholeNumbers[i] < 40 && wholeNumbers[i] > 29) { //if whole number is in the 30s
        sum = sum + wholeNumbers[i];
        System.out.println ("The sum in the 30s is " + sum);
      } else if (wholeNumbers[i] < 50 && wholeNumbers[i] > 39) { //if whole number is less than 40s
        sum = sum + wholeNumbers[i];
        System.out.println ("The sum in the 40s is " + sum);
      } else if (wholeNumbers[i] < 60 && wholeNumbers[i] > 49) { //if whole number is in the 50s
        sum = sum + wholeNumbers[i];
        System.out.println ("The sum in the 50s is " + sum);
      } else if (wholeNumbers[i] < 70 && wholeNumbers[i] > 59) { //if whole number is in the 60s
        sum = sum + wholeNumbers[i];
        System.out.println ("The sum in the 60s is " + sum);
      } else if (wholeNumbers[i] < 80 && wholeNumbers[i] > 69) { //if whole number is in the 70s
        sum = sum + wholeNumbers[i];
        System.out.println ("The sum in the 70s is " + sum);
      } else if (wholeNumbers[i] < 90 && wholeNumbers[i] > 79) { //if whole number is in the 80s
        sum = sum + wholeNumbers[i];
        System.out.println ("The sum in the 80s is " + sum);
      } else if (wholeNumbers[i] < 100 && wholeNumbers[i] > 89) { //if whole number is in the 90s
        sum = sum + wholeNumbers[i];
        System.out.println ("The sum in the 90s is " + sum);
      } 
    }
    return x; 
  }
  
  //4. Add a procedure called totals2 which will look similar to totals, but calculates the totals (sums) slightly differently. 
  
  //The procedure will output the total of all numbers entered less than 10, the total of all numbers entered less than 20, 
  
  //the total of all numbers entered less than 30, ... and the total of all numbers entered less than 100 (so 88 will be included in both totals for numbers less than 90 and less than 100).
  
  public static int[] totals2(int x[]) {
    
    Scanner userInput = new Scanner(System.in); //declare scanner
    
    int sum = 0; //declare integer variable
    int[] wholeNumbers = new int[100]; //declare array variable
    
    System.out.println("How many numbers would you like to enter?"); //prompt user to enter the number of whole numbers
    int ans = userInput.nextInt(); //store input
    
    System.out.println("Enter whole numbers"); //prompt user to enter the whole numbers
    for (int i = 0; i < ans; i++) { //start for loop to stop when the number is less than the number of whole numbers entered
      do {
        wholeNumbers[i] = userInput.nextInt(); //store whole numbers in array
      } while (x[i] <= 0 && x[i] > 100); //do whle the number is less than and equal to zero and greater than 100
    }
    for (int i = 0; i < ans; i++) {
      if (wholeNumbers[i] < 10) { //if whole number is less than 10
        sum = sum + wholeNumbers[i];
        System.out.println ("The sum less than 10 is " + sum);
      } else if (wholeNumbers[i] < 20) { //if whole number is less than 20
        sum = sum + wholeNumbers[i];
        System.out.println ("The sum less than 20 is " + sum);
      } else if (wholeNumbers[i] < 30) { //if whole number less than 30
        sum = sum + wholeNumbers[i];
        System.out.println ("The sum less than 30 is " + sum);
      } else if (wholeNumbers[i] < 40) { //if whole number less than 40
        sum = sum + wholeNumbers[i];
        System.out.println ("The sum less than 40 is " + sum);
      } else if (wholeNumbers[i] < 50) { //if whole number is less than 50
        sum = sum + wholeNumbers[i];
        System.out.println ("The sum less than 50 is " + sum);
      } else if (wholeNumbers[i] < 60) { //if whole number is less than 60
        sum = sum + wholeNumbers[i];
        System.out.println ("The sum less than 60 is " + sum);
      } else if (wholeNumbers[i] < 70 ) { //if whole number is less than 70
        sum = sum + wholeNumbers[i];
        System.out.println ("The sum less than 70 is " + sum);
      } else if (wholeNumbers[i] < 80 ) { //if whole number is less than 80
        sum = sum + wholeNumbers[i];
        System.out.println ("The sum less than 80 is " + sum);
      } else if (wholeNumbers[i] < 90 ) { //if whole number is less than 90
        sum = sum + wholeNumbers[i];
        System.out.println ("The sum less than 90 is " + sum);
      } else if (wholeNumbers[i] < 100 ) { //if whole number is less than 100
        sum = sum + wholeNumbers[i];
        System.out.println ("The sum less than 100 is " + sum);
      } 
    }
    return x; 
  }
}
