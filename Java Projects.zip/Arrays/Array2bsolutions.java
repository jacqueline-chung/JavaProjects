/*
 * Array Exercises (Level 2)
 * [Array2b.java]
 * Author: Duffy Du
 * Sept 16, 2015
 */

import java.util.Scanner;
class Array2bsolutions {
  public static void main(String args[]){
    
    Scanner input = new Scanner(System.in);
    int userInput;
    
    System.out.println("Enter 1 for count occurrences");
    System.out.println("Enter 2 for count occurrences 2 ");
    System.out.println("Enter 3 for totals");
    System.out.println("Enter 4 for totals 2");
    userInput = input.nextInt();
    
    while (userInput<1||userInput>4){
      System.out.println("invalid input, please enter a number between 1 and 4");
      userInput = input.nextInt();
    }
    if (userInput==1){
      countOccurrences();
    } else if (userInput==2){
      countOccurrences2();
    } else if (userInput==3){
      totals();
    } else if (userInput==4){ 
      totals2();
    }
  }
  
  //********************* countOccurrences() method ***************************
  public static void countOccurrences(){
    Scanner input = new Scanner(System.in);
    
    int amountOfNumbers;
    int[] numbers;
    int[] occurrences = new int[10];
    int userInput;
    
    System.out.println("How many numbers are you going to enter?");
    amountOfNumbers = input.nextInt();
    numbers = new int[amountOfNumbers];
    
    for (int i=0; i<numbers.length; i++){
      System.out.println("Enter a natural number from 1 to 10: ");
      System.out.println("enter a number outisde the range to exit entering numbers and display the # of occurences");
      userInput = input.nextInt();
      
      if(userInput>=1 && userInput<=10){
        numbers[i] = userInput; 
      }else {
        System.out.println("break");
        break; 
      }
      
      occurrences[(numbers[i]-1)]++;
      System.out.println("occurrences[numbers[i]-1]++ = " + occurrences[(numbers[i]-1)]);
    }
    
    for(int i=0; i<10; i++){
      System.out.println("number " + (i+1) + ", # of occurences: "+ occurrences[i]);
    }
    
  }
  
  //********************* countOccurrences2() method *******************
  public static void countOccurrences2(){
    Scanner input = new Scanner(System.in);
    
    int amountOfNumbers;
    int[] numbers;
    int[] occurrences = new int[11];
    int userInput;
    
    System.out.println("How many numbers are you going to enter?");
    amountOfNumbers = input.nextInt();
    numbers = new int[amountOfNumbers];
    
    for (int i=0; i<numbers.length; i++){
      System.out.println("Enter a natural number from 15 to 25: ");
      System.out.println("enter a number outisde the range to exit entering numbers and display the # of occurences");
      userInput = input.nextInt();
      
      if(userInput>=15 && userInput<=25){
        numbers[i] = userInput; 
      }else {
        System.out.println("break");
        break; 
      }
      
      occurrences[(numbers[i]-15)]++;
      System.out.println("occurrences[numbers[i]-15]++ = " + occurrences[(numbers[i]-15)]);
    }
    
    for(int i=0; i<11; i++){
      System.out.println("number " + (i+15) + ", # of occurences: "+ occurrences[i]);
    }
    
  }
  
  //*********************** totals() ***************************
  public static void totals(){
    Scanner input = new Scanner(System.in);
    
    int userInput;
    int amountOfNumbers;
    int[] sums = new int[10];
    
    System.out.println("How many numbers are you going to enter?");
    amountOfNumbers = input.nextInt();
    
    for (int i=0; i<amountOfNumbers; i++){
      System.out.println();
      System.out.println("Enter a natural number from 0 to 99: ");
      System.out.println("enter a number outisde the range to exit entering numbers and display the # of occurences");
      userInput = input.nextInt();
      
      if (userInput>=0 && userInput<=9){
        sums[0]+= userInput;
      } else if (userInput>=10 && userInput<=19){
        sums[1]+= userInput;
      } else if (userInput>=20 && userInput<=29){
        sums[2]+= userInput;
      } else if (userInput>=30 && userInput<=39){
        sums[3]+= userInput;
      } else if (userInput>=40 && userInput<=49){
        sums[4]+= userInput;
      } else if (userInput>=50 && userInput<=59){
        sums[5]+= userInput;
      } else if (userInput>=60 && userInput<=69){
        sums[6]+= userInput;
      } else if (userInput>=70 && userInput<=79){
        sums[7]+= userInput;
      } else if (userInput>=80 && userInput<=89){
        sums[8]+= userInput;
      } else if (userInput>=90 && userInput<=99){
        sums[9]+= userInput;
      } else {
        System.out.println("break");
        break; 
      }
    }
    
    System.out.println("sum of numbers from 0 to 9 = " + sums[0]);
    System.out.println("sum of numbers from 10 to 19 = " + sums[1]);
    System.out.println("sum of numbers from 20 to 29 = " + sums[2]);
    System.out.println("sum of numbers from 30 to 39 = " + sums[3]);
    System.out.println("sum of numbers from 40 to 49 = " + sums[4]);
    System.out.println("sum of numbers from 50 to 59 = " + sums[5]);
    System.out.println("sum of numbers from 60 to 69 = " + sums[6]);
    System.out.println("sum of numbers from 70 to 79 = " + sums[7]);
    System.out.println("sum of numbers from 80 to 89 = " + sums[8]);
    System.out.println("sum of numbers from 90 to 99 = " + sums[9]);
    
  }
  
  //*********************** totals2() ***************************
  public static void totals2(){
    Scanner input = new Scanner(System.in);
    
    int userInput;
    int amountOfNumbers;
    int[] sums = new int[10];
    
    System.out.println("How many numbers are you going to enter?");
    amountOfNumbers = input.nextInt();
    
    for (int c=0; c<amountOfNumbers; c++){
      System.out.println();
      System.out.println("Enter a natural number from 0 to 99: ");
      System.out.println("enter a number outisde the range to exit entering numbers and display the # of occurences");
      userInput = input.nextInt();
      
      if (userInput>=0 && userInput<=9){
        for (int i=0; i<10; i++){
          sums[i]+= userInput;
        }
      } else if (userInput>=10 && userInput<=19){
        for (int i=1; i<10; i++){
          sums[i]+= userInput;
        }
      } else if (userInput>=20 && userInput<=29){
        for (int i=2; i<10; i++){
          sums[i]+= userInput;
        }
      } else if (userInput>=30 && userInput<=39){
        for (int i=3; i<10; i++){
          sums[i]+= userInput;
        }
      } else if (userInput>=40 && userInput<=49){
        for (int i=4; i<10; i++){
          sums[i]+= userInput;
        }
      } else if (userInput>=50 && userInput<=59){
        for (int i=5; i<10; i++){
          sums[i]+= userInput;
        }
      } else if (userInput>=60 && userInput<=69){
        for (int i=6; i<10; i++){
          sums[i]+= userInput;
        }
      } else if (userInput>=70 && userInput<=79){
        for (int i=7; i<10; i++){
          sums[i]+= userInput;
        }
      } else if (userInput>=80 && userInput<=89){
        for (int i=8; i<10; i++){
          sums[i]+= userInput;
        }
      } else if (userInput>=90 && userInput<=99){
        for (int i=9; i<10; i++){
          sums[i]+= userInput;
        }
      } else {
        System.out.println("break");
        break; 
      }
    }
    
    System.out.println("sum of numbers less than 10 = " + sums[0]);
    System.out.println("sum of numbers less than 20 = " + sums[1]);
    System.out.println("sum of numbers less than 30 = " + sums[2]);
    System.out.println("sum of numbers less than 40 = " + sums[3]);
    System.out.println("sum of numbers less than 50 = " + sums[4]);
    System.out.println("sum of numbers less than 60 = " + sums[5]);
    System.out.println("sum of numbers less than 70 = " + sums[6]);
    System.out.println("sum of numbers less than 80 = " + sums[7]);
    System.out.println("sum of numbers less than 90 = " + sums[8]);
    System.out.println("sum of numbers less than 100 = " + sums[9]);
    
  }
  
}
