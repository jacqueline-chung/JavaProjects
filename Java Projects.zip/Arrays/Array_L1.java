/*
 * Array 1 Solutions
 * September 21, 2015
 * Store 10 numbers in an array.  
 */
import java.util.Scanner;// scanner to get input

public class Array_L1{
  
  static Scanner myScanner = new Scanner(System.in);//declare scanner class as a global variable
  
  public static void main(String[] args) {
    final int MAX = 10;
    
    int answer = 0;// Local variable
    
    int num[] = new int [MAX];  //Instantiate array
    
    initializeArray(num);
    enterFromKeyboard (num);
    
    //Creating a menu driven program
    
    do {
      System.out.println ("Please choose the option that you would like to execute. Enter -1 to exit:");
      System.out.println ("1 Count the number of whole numbers that were entered");
      System.out.println ("2 Display");
      System.out.println ("3 Display Reverse");
      System.out.println ("4 Sum");
      System.out.println ("5 Average");
      System.out.println ("6 Find Maximum");
      System.out.println ("7 Find Minimum");
      System.out.println ("8 Search");
      
      answer = myScanner.nextInt();
      if (answer ==1){
        countWhole(num);
      }
      else if (answer ==2){
        display(num);
      }
      else if (answer ==3){
        displayReverse(num);
      } 
      else if (answer ==4){
        sum(num);
      }
      else if (answer ==5){
        average(num);
      }
      else if (answer ==6){
        findMax(num);
      }
      else if (answer ==7){
        findMin(num);
      }
      else if (answer ==8){
        search(num);
      }
    }while (answer!=-1);
    
    
    System.out.println ("Thank you for using the program");
    
  } //main method
  
  public static void initializeArray (int [] list)
  {    
    for (int i = 0 ; i < list.length ; i++)
    {    
      list [i] = -1; //store values in array
    }
  }
  
  public static void enterFromKeyboard  (int [] list)
  {    
    System.out.println ("Please enter 10 integers below.");
    
    //Ask for 10 numbers and store in array
    for (int i = 0; i < list.length; i++)
    {
      System.out.println ("Enter number " + (i + 1) + ": ");
      list [i] = myScanner.nextInt (); //store values in array
    }
  }
  
  
  public static void countWhole (int [] list)
  {    
    int counter = 0;
    for (int i = 0; i < list.length; i++)
    {      
      if (list [i] > 0){
        counter++ ; //store values in array
      }
    }
    System.out.println ("The number of whole numbers entered is " + counter);
  }
  
  public static void display (int [] list) 
  {    
    System.out.println ("The numbers you entered are:");
    
    //Ask for 10 numbers and store in array
    for (int i = 0; i < list.length; i++)
    {
      System.out.println( i + " =  " + list[i] );
      
    }
  }
  
  public static void displayReverse (int [] list) 
  {    
    System.out.println ("The numbers you entered in reverse order are:");
    
    //Ask for 10 numbers and store in array
    for (int i = (list.length-1); i >= 0; i--)
    {
      System.out.println( i + " =  " + list[i] );
      
    }
  }
  
  public static void sum(int [] list)
  {
    int listSum = 0;
    
    for (int i=0; i < list.length; i++) {
      listSum += list[i];
    }
    
    System.out.println("The sum of the numbers is : " + listSum);
  }
  
  public static void average(int [] list)
  {
    int listSum = 0;
    
    for (int i=0; i < list.length; i++) {
      listSum += list[i];
    }
    int avg = listSum/list.length;
    System.out.println("The average of the numbers is : " + avg);
  }
  
  public static void findMax(int [] list) {
    int max = list[0];
    for (int i = 1; i < list.length; i++) {
      if (max < list[i]) {
        max = list[i];
      }
    }
    System.out.println("The max number in the list is: " + max);
  }
  
  public static void findMin(int [] list) {
    int min = list[0];
    for (int i = 1; i < list.length; i++) {
      if (min > list[i]) {
        min = list[i];
      }
    }
    System.out.println("The min number in the list is: " + min);
  }
  
  public static void search(int [] list) {
    System.out.println("Please enter number you are looking for:");
    int num = myScanner.nextInt();
    String locations = "";
    for (int i =0; i < list.length; i++) {
      if (num == list[i]) {
        locations = i + " ";
      }
    }
      System.out.println("The number " + num + " is found in the following positons: " + locations);
  }
  
  public static void bubble  (int [] list) {
    int temp=0;
    for (int i = 0 ; i < list.length  ; i++)
    {
      
      //Ask for 10 numbers and store in array
      for (int j = 0 ; j < list.length-1-i  ; j++)
      {
        if(list[j]>list[j+1])
          //Swap
         temp = list[j];
        list[j]= list[j+1];
        list[j+1]= temp;    
      }
    }
  }
}
