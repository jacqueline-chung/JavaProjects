/* [Array2]
 * Write a procedure called InitializeArray which will assign the value -1 to every element of the array.
 * Author: Jacqueline Chung
 * Date: September 14, 2015
 */

import java.util.Scanner;
class Array2 {
  public static void main(String args[]) {  //main method
    
    Scanner userInput = new Scanner(System.in);
    
    int[] array = new int[10];
    int r = 0;
    
    //12. Add a loop so that the user can make other choices from the menu for the numbers that the user entered.
    while (r != 11) {
      
      System.out.println("Enter the procedure. 1) InitializeArray 2)EnterFromKeyboard 3)CountWhole 4)Display 5)DisplayReverse 6)Sum 7)Average 8)FindMax 9)FindMin 10)Search 11)Quit");
      r = userInput.nextInt();
      
      if (r == 1) {
        InitializeArray(array);
      } else if (r == 2) {
        EnterFromKeyboard(array);
      } else if (r == 3) {
        CountWhole(array);
      } else if (r == 4) {
        Display(array);
      } else if (r == 5) {
        DisplayReverse(array);
      } else if (r == 6) {
        Sum(array);
      } else if (r == 7) {
        Average(array);
      } else if (r == 8) {
        FindMax (array);
      } else if (r == 9) {
        FindMin (array);
      } else if (r == 10) {
        Search(array);
      }
    }
    System.out.println("Thanks!");
  }
  
  public static int[] InitializeArray(int x[]) {
    for (int i = 0; i < 10; i++) {
      x[i] = -1;
    }
    return x;
  }
  //Add a procedure called EnterFromKeyboard which will enter UP TO 10 integers and store them in the array.
  public static int[] EnterFromKeyboard(int x[]) {
    Scanner userInput = new Scanner(System.in);
    
    System.out.println("Enter 10 integers");
    for (int i = 0; i < 10; i++) {
      x[i] = userInput.nextInt();
    }
    return x;
  }
  
// Add a procedure called CountWhole which will calculate and display the number of whole numbers entered into the array. (Positive integer values)
  public static int CountWhole(int x[]) {
    int count = 0;
    
    for (int i = 0; i < 10; i++) {
      if (x[i] > 0) {
        count++;
      }
    }
    System.out.println("The number of positive whole numbers are: " + count);
    return count;
  }
  
  //6. Add a procedure called Display which will display the list of inputted integers in the order entered. (e.g. The integers in order entered is   8  12  32  43  14  12.)
  public static int[] Display(int x[]) {  
    System.out.print("The integers entered are: ");
    
    for (int i = 0; i < 10; i++) {
      System.out.print(x[i] + " ");
    }
    System.out.println();
    return x;
  }
  
  //Add a procedure called DisplayReverse which will display the list of inputted integers in reverse order entered.
  public static int[] DisplayReverse(int x[]) {
    for (int i = 9; i >= 0; i--) {
      System.out.print(x[i] + " ");
    }
    System.out.println();
    return x;
  }
  
  //8. Add a procedure called Sum that will calculate and display the sum of all the numbers entered.
  public static int[] Sum(int x[]) {
    int sum = 0;
    
    System.out.print("The integers entered are: ");
    
    for (int i = 0; i < 10; i++) {
      sum = sum + x[i];
    }
    System.out.println("The sum of the integers are: " + sum);
    return x;
  }
  
  //9. Add a procedure called Average that will calculate and display the average of all the numbers entered correct to 1 decimal place.
  public static int[] Average(int x[]) {
    int sum = 0, average;
    
    System.out.print("The integers entered are: ");
    
    for (int i = 0; i < 10; i++) {
      sum = sum + x[i];
    }
    
    average = sum/10;
    System.out.print("The average of the integers entered are: " + average);
    System.out.println();
    return x;
  }
  
  //10. Add 2 procedures called FindMax and FindMin which will calculate and display the maximum number and the minimum number stored in the array respectively.
  public static int[] FindMax(int x[]) {
    int big = 0;
    
    for (int i = 0; i < 10; i++) {
      if (x[i] > big) {
        big = x[i];
      }
    }
    System.out.println("The largest number is " + big);
    System.out.println();
    return x;
  }
  
  public static int[] FindMin(int x[]) {
    int small = 0;
    
    for (int i = 0; i < 10; i++) {
      if (x[i] < x[i-1]) {
        small = x[i];
      }
    }
    System.out.println("The smallest number is " + small);
    System.out.println();
    return x;
  }
  
  //11. Add a procedure called Search that will display the position(s) in the array a specific number occupies.
  public static int[] Search(int x[]) {
    Scanner userInput = new Scanner(System.in);
    
    int a;
    System.out.println("Search for an integer");
    a = userInput.nextInt();
    
    for (int i = 0; i < 10; i++) {
      if (x[i] == a) {
        System.out.println(x[i] + "occupies" + i); 
      } else {
        System.out.println("It doesn't exist."); 
      }
    }
    return x;
  }
}