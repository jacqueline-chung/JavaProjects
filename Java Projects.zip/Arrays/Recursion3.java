/*Name: Jacqueline Chung
 * File: Recursion 3
 * Teacher: Agreghetti
 * Date: October 15, 2015
*/
import java.util.Scanner;

public class Recursion3 {
  public static void main (String args[]) {
   
    Scanner myScanner = new Scanner(System.in);
   
    System.out.println("Enter a number for the base");
    int base = myScanner.nextInt();
        
    System.out.println("Enter a number for the power");
    int power = myScanner.nextInt();
   
    System.out.println("Base " + base + " to the power of " + power + " is " + powerValue(base, power));
  }
  
  public static int powerValue(int b, int p) {
    if(p == 0) {
      return 1;
    } else if (p == 1) {
      return b;
    } else {
      return b * powerValue(b, p-1); 
    }
  }
}