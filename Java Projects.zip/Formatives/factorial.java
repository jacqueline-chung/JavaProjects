/* [factorial]
 * Write a method that checks whether the number they input is a perfect number and output a message indicating whether it is perfect or not. (use a procedure) 
 * Author: Jacqueline Chung
 * Date: September 10, 2015
 */

//import java.util.Scanner;
//class factorial {
//  
//  public static void main(String args[]) {  //main method
//    
//    Scanner userInput = new Scanner(System.in); 
//    
//    int num, product = 1;
//    
//    System.out.println ("Enter an integer.");
//    num = userInput.nextInt();
//    
//    for (int i = 1; i <= num; i++) {
//        product = product * i;
//    }
//    
//    System.out.println("The product is " + product);
//  }
//}    

import java.util.Scanner;
public class factorial {
  public static void main(String args[]) {

        Scanner input = new Scanner(System.in);
        int a, b, c, d;
        double length;         

        //get two corrdinates
        System.out.print("Enter the first point: "); //ask the user for a point
        a = input.nextInt();
        b = input.nextInt();
        
        System.out.print("Enter the second point: "); //ask the user for a point
        c = input.nextInt();
        d = input.nextInt();
        
        length = distance(a, b, c, d);
        
        System.out.println("The distance of the coordinates is: " + length); //output message to user about what the hypothenuse is

    }
  
  public static double distance (int w, int x, int y, int z) {
    double h;
    h = Math.sqrt(Math.pow(w - y, 2) + Math.pow(x - z, 2));
    //Math.sqrt(Math.pow(side1, 2) + Math.pow(side2, 2));
    return h;
  }
}
