import java.util.Random; //required for Random generator
import java.util.Scanner;

public class RecBin { //
  public static void main(String args[]) {
    
    Scanner input = new Scanner(System.in);
 
    String[] arrayNames = {"Bob", "Cat", "Nate", "Quinn", "Roger", "Timmy"};
    System.out.println("Enter the name you want to search");
    int sName = input.nextInt();
    
    int max = arrayNames.length;
    int min = 0;
      
    recBin(arrayNames, max, min, sName);
  }
  
  public static int recBin (String[] List, int high, int low, int target) {
    if (low <= high) {
      
    }
  }
}
  