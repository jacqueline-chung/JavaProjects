/* [Search2.java]
 * Create a menu driven program that will run any procedure described below. Use only local variables.
 * Author: Jacqueline Chung
 * Date: November 3, 2015, 2015
 */ 

import java.util.Scanner;
import java.util.Random;
import java.io.*;
import java.io.PrintWriter;
import java.io.File;

public class SequentialSearch {
  public static void main(String[] args) throws Exception {  //main method 
    Scanner input = new Scanner(System.in);//declare scanner
    
    //declare counter
    int counter = 0, count = -1;
    
    File myFile = new File("unsort.dat");
    //PrintWriter output = new PrintWriter(myFile);
    
    Scanner fileScanner = new Scanner(myFile);//declare scanner
    
    while(fileScanner.hasNext()) { // Read data from a file
      fileScanner.nextLine();
      counter++;
    }    
    
    
    fileScanner.close();
    
    String[] names = new String [counter/2];
    String[] numbers = new String [counter/2];
    
    Scanner fileScanner2 = new Scanner(myFile);//declare scanner
    
    while(fileScanner2.hasNext()) { // Read data from a file
      
      count++;
      names[count]= fileScanner2.nextLine();
      numbers[count] = fileScanner2.nextLine();
      
      
    } 
    
    for (int i = 1; i < names.length; i++) {
      System.out.println(names[i] + " " + numbers[i]);
    }
    
    System.out.println();
    
    fileScanner2.close();
    
    //Insertion Sort
    int j;
    String temp, tempNum; //declare j and temp variables
    
    //start for loop until it reaches the array length
    for (int i = 1; i < names.length; i++) {
      temp = names[i]; //set temp value to array
      tempNum = numbers[i];
      
      j = i; //set j equal i
      
      //while j is greater than 0 and if the previous ones is bigger
      while (j > 0 && names[j - 1].compareToIgnoreCase(temp) > 0) { 
        names[j] = names[j - 1]; //swap
        numbers[j] = numbers[j - 1]; //swap
        j--; 
      } // while loop ends
      names[j] = temp; //swap 
      numbers[j] = tempNum;
    } // for loop ends
    
    System.out.println("SORTED LIST:");
    for (int i = 0; i < names.length; i++) {
      System.out.println(names[i] + " " + numbers[i]); //print array
    }
    
    //store sorted list in the file called Sorted.dat
    File file2 = new File("Sorted.dat");
    //create a print writer
    PrintWriter writer = new PrintWriter(file2);
    
    for(int i = 0; i < names.length; i++){ //write into file
      writer.println(names[i]);
      writer.println(numbers[i]);
    }
    writer.close();
    
    ////SEQUENTIAL SEARCH///////////////
    int location = -1;
    
    System.out.println("Enter the name you want to search"); //prompt user 
    String sName = input.nextLine(); //store input from user
    
    for (int i = 0; i < names.length; i++) {  
      if (names[i].compareTo(sName) == 0) {
        location = i;  
      }
    }
    if (location != -1) {
      System.out.println("Index (Sequential): " +  location); //ouput message   
    } else {
      System.out.println("Not found"); //ouput message   
    }
  }
}

