/**
 * 2. Open the file: Unsort.dat which contains Names and phone numbers stored in the following format:
 * Porter, Adam
 * 905 294 1252
 * hocking, Dan
 * 905 294 1238 (assume you do not know the number of names stored)
 * a) Store the data into an array data type
 * b) Output the stored data to screen
 * c) Sort the names in alphabetical order using Insertion sort and output to screen
 * d) Store the sorted names in a file called Sorted.dat
 * Save the program as [InsertSortClass.java]
 * Author: Duffy Du
 * Nov 1, 2015
 */

import java.io.*;
import java.util.Scanner;

public class InsertSortClass {
  
  public static void main(String[] args) throws Exception { 
    
    String[] names,numbers;
    int counter=0,count=-1;
    String temp, tempNum;
    int j;
    
    //create a file
    File file1 = new File("Unsort.dat");
    
    
    //scanner
    Scanner fileScanner1 = new Scanner(file1);
    while (fileScanner1.hasNextLine()){
      fileScanner1.nextLine();
      
      counter++;
    }
    
    
    fileScanner1.close();
    
    names = new String[counter/2];
    numbers = new String[counter/2];
    //read again
    Scanner fileScanner2 = new Scanner(file1);
    while (fileScanner2.hasNext()){
      count++;
      names[count] = fileScanner2.nextLine();
      numbers[count] = fileScanner2.nextLine();
    }
    fileScanner2.close();
    
    
    //display
    for (int i=0;i<names.length;i++){
      System.out.println(names[i]+ " - " +  numbers[i]);
    }
    
    //insertion sort
    for(int i=1;i<names.length;i++){
      temp = names[i];
      tempNum = numbers[i];
      j=i;
      
      while (j>0&&names[j-1].compareToIgnoreCase(temp)>0){
        names[j] = names[j-1];
        numbers[j] = numbers[j-1];
        j--;
      }
      
      names[j]=temp;
      numbers[j] = tempNum;
    }
    
    System.out.println();
    //display sorted result
    for (int i=0;i<names.length;i++){
      System.out.println(names[i]+ " - " +  numbers[i]);
    }
    
    
    //store sorted list in the file called Sorted.dat
    File file2 = new File("Sorted.dat");
    System.out.println("writing into the file...");
    //create a print writer
    PrintWriter writer = new PrintWriter(file2);
    
    for(int i=0;i<names.length;i++){
      writer.println(names[i]);
      writer.println(numbers[i]);
    }
    writer.close();
    
    
  }
  
  
}
