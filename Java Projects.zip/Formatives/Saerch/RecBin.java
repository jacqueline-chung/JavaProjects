import java.util.Random; //required for Random generator

public class RecBin { //
  public static void main(String args[]) {
 
    String[] arrayNames = {"Bob", "Cat", "Nate", "Quinn", "Roger", "Timmy"};
    System.out.println("Enter the name you want to search");
    int sName = myScanner.nextInt();
    
    max = arrayNames.length;
    min = 0;
      
    recBin(arrayNames, max, min, sName);
  }
  
  public static int recBin (String[] List, int max, int min, target) {
    if (low <= high) {
      
    }
  }
}
  