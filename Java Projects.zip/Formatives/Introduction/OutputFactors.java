/* [OutputFactors]
 * a method that outputs all the factors of the number the user entered
 * Author: Jacqueline Chung
 * Date: September 10, 2015
 */

import java.util.Scanner;
class OutputFactors {
  
  public static void main(String args[]) {  //main method
    
    Scanner userInput = new Scanner(System.in); 
    
    int num;
    
    System.out.println ("Enter an integer.");
    num = userInput.nextInt();
    
    for (int i = 1; i <= num; i++) {
      if (num % i == 0) {
        System.out.println(i + " ");
      } 
    }
    
  }
}    


