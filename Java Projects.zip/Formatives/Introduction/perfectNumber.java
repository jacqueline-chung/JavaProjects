/* [perfectNumber]
 * Write a method that checks whether the number they input is a perfect number and output a message indicating whether it is perfect or not. (use a procedure) 
 * Author: Jacqueline Chung
 * Date: September 10, 2015
 */

import java.util.Scanner;
class perfectNumber {
  
  public static void main(String args[]) {  //main method
    
    Scanner userInput = new Scanner(System.in); 
    
    int num, sum = 0;
    
    System.out.println ("Enter an integer.");
    num = userInput.nextInt();
    
    for (int i = 1; i < num; i++) {
      if (num % i == 0) {
        System.out.println(i + " ");
        sum = sum + i;
      } 
    }
    
    System.out.println("The sum is " + sum);
    
    if (sum == num) {
      System.out.println(num + " is a perfect number");
    } else {
      System.out.println(num + " is not a perfect number");
    }
  }
}    
