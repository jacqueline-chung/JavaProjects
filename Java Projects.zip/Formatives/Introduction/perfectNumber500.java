/* [perfectNumber500]
 * Output all the perfect numbers between 1 to 500
 * Author: Jacqueline Chung
 * Date: September 10, 2015
 */

class perfectNumber500 {
  
  public static void main(String args[]) {  //main method
    
    int num = 1;  
    
    System.out.println("The perfect numbers between 1 and 500 are: ");
    for (int i = 0; i <= 500; i++) {
      if (perfectNum(num) == 0) {
        System.out.print(num + " ");
      }
      num++;
    }
  }
  
  public static int perfectNum (int x) {
    int sum = 0;
    for (int i = 1; i < x; i++) {
      if (x % i == 0) {
        sum = sum + i;
      } 
    }
    if (sum == x) {
      return 0;
    } else {
      return 1;
    }
  }
}    
