public class ToyApplication {
  
  public ToyApplication() { 
    /* YOUR CONSTRUCTOR CODE HERE*/
  }
  
  public static void main(String[] args) { 
    //create toy object
    Toy connect4 = new Toy("Connect 4", 2.25, 11.99);
    
    System.out.println("My toy name is " + connect4.getName());
    
    connect4.setName("Connect Four");
    System.out.println("My toy name is " + connect4.getName());
    
    Toy monopoly = new Toy ("Monopoly", 4.89, 19.99);
    System.out.println("My toy name is " + monopoly.getName());
    
    //Toy [] myToys; //create array of objects
  }
}
