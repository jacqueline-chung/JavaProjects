public class Nickel extends Coin {
  //private String name;
  
//  public Circle(){
//    this.name="Nickel";
//    super.name="Nickel";
//    //this.radius = 10;
//  }
  
  public double getValue() {
    //System.out.println("Value: " + 0.05);
    return 0.05;
  }
}


