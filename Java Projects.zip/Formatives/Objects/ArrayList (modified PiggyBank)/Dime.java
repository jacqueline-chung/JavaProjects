public class Dime extends Coin {
  public double getValue() {
    return 0.10;
  }
}


