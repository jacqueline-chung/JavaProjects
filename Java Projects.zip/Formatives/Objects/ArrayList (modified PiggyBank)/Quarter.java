public class Quarter extends Coin {
  //private String name;
  
//  public Circle(){
//    this.name="Quarter";
//    super.name="Quarter";
//    //this.radius = 10;
//  }
  
  public double getValue() {
    return 0.25;
  }
}


