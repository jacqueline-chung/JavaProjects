/* Name: Jacqueline Chung
 * Teacher: Mrs. Andrighetti
 * Date: December 15, 2015
 * Description:  MySavings appliction.  Will provide menu functionality for saving money in a PiggyBank
 */
import java.util.ArrayList;
import java.util.Scanner;

public class MySavings {
  public static void main(String[] args) {  //main method -- menu driven application for storing money in a piggy bank
    ArrayList<Double> coins = new ArrayList<Double>(); // Create an ArrayList that holds references to String
    
    Scanner myScanner = new Scanner(System.in); // create scanner object for input
    PiggyBank bank = new PiggyBank(); // create an new PiggyBank object.
    int choice; //declare variable for user input choice
    
    //create objects for each coin
    Penny p = new Penny();
    Nickel n = new Nickel();
    Dime d = new Dime();
    Quarter q = new Quarter();
    
    int pcount = 0, ncount = 0, dcount = 0, qcount = 0; //declare counters for coins
    
    //print values of all the coins
    System.out.println("Value of penny " + p.getValue());
    System.out.println("Value of nickel " + n.getValue());
    System.out.println("Value of dime " + d.getValue());
    System.out.println("Value of quarter " + q.getValue());

    do {
      //print choices user can pick
      System.out.println("1. Show total in bank.");
      System.out.println("2. Add a penny.");
      System.out.println("3. Add a nickel.");
      System.out.println("4. Add a dime.");
      System.out.println("5. Add a quarter.");
      System.out.println("6. Take money out of the bank.");
      System.out.println("Enter 0 to quit.");
      
      System.out.print("Enter your choice:"); //prompt user to choose
      choice = myScanner.nextInt(); //receive and store value
      
      if (choice == 1) { //if user chooses 1
        System.out.println("Total amount in bank: $" + bank.getTotal());
        
        //print summary, the number of coins
        System.out.println("Summary: ");
        System.out.println("# of Pennies: " + pcount);
        System.out.println("# of Nickels: " + ncount);
        System.out.println("# of Dimes: " + dcount);
        System.out.println("# of Quarters: " + qcount);
        
        //loop to print all the trasnactions made
        for (int i = 0; i < coins.size(); i++) {
          System.out.println("Transaction #" + (i+1) + ": " + coins.get(i)); //print transactions
        }
        
      } else if (choice == 2) { //if user chooses 2
        bank.addPenny(); //add penny to bank
        coins.add(p.getValue()); //add value of penny to arraylist
        System.out.println("Added Penny"); //print message that a coin was added
        pcount++; //add to counter
      } else if (choice == 3) { //if user chooses 3
        bank.addNickel(); //add nickel to bank
        coins.add(n.getValue()); //add value of nickel to arraylist
        System.out.println("Added Nickel"); //print message that a coin was added
        ncount++; //add to counter
      } else if (choice == 4) { //if user chooses 4
        bank.addDime(); //add dime to bank
        coins.add(d.getValue()); //add value of quarter to arraylist
        System.out.println("Added Dime"); //print message that a coin was added
        dcount++; //add to counter
      } else if (choice == 5) { //if user chooses 5
        bank.addQuarter(); //add quarter to bank
        coins.add(q.getValue()); //add value of quarter to arraylist
        System.out.println("Added Quarter"); //print message that a coin was added
        qcount++; //add to counter
      } else if (choice == 6) { //if user chooses 6
        System.out.print("Enter amount to remove: $");
        double amount = myScanner.nextDouble(); //declare amount variable that stores input form user for removal
        
        if (amount >= bank.getTotal()) { //if amount user wants to remove is greater or equal to the total in the bank
          coins.clear(); //remove all elements in array
          pcount = 0; ncount = 0; dcount = 0; qcount = 0; //set all counters equal to 0
        } else if (amount == 0) {
          System.out.print("Piggy bank is empty!"); //print message that piggy bank is empty
        }
        
        for (int  i = 0; i < coins.size(); i++) {
          if (amount >= 5) {
            
          } else if (amount >= 10) {
            
          } else if (amount >= 25) {
            
          } else {
            
          }
        }
        
        double amountRemoved = bank.removeAmount(amount); //remove amoutn from bank
        System.out.println("You removed: $ " + amountRemoved); //print amount removed
      }      
    } while (choice != 0); //do while the choice is not zero
    
    System.out.println("Thanks for using the MySavings Application."); //print a message to user that they have exited the program
    myScanner.close();
  } //end main method
}