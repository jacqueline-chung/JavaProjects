public class Penny extends Coin {
//  private String name;
//  private double radius;
  
//  public Circle(){
//    this.name="Penny";
//    super.name="Penny";
//    //this.radius = 10;
//  }
  
  public double getValue() {
    //System.out.println("Value: " + 0.01);
    return 0.01;
  }
}


