public class Penny extends Coin{
  public double getValue(){
  //  System.out.println("Penny: 0.01$");
    return 0.01;
  }
}