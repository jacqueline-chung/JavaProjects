public class Quarter extends Coin{
  public double getValue(){
    //System.out.println("Quarter: 0.25$");
    return 0.25;
  }
}