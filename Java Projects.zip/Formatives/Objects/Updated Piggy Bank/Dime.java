public class Dime extends Coin{
  public double getValue(){
   // System.out.println("Dime: 0.10$");
    return 0.10;
  }
}