import java.util.Scanner;
import java.util.ArrayList; 
/**
 * Name: Mrs. Andrighetti
 * Date: December 15, 2015
 * Description:  MySavings appliction.  Will provide menu functionality for 
 *               saving money in a PiggyBank
 */
public class MySavings {
  
  /**
   * main method -- menu driven application for storing money in a piggy bank
   */
  public static void main(String[] args) { 
    
    Penny penny = new Penny();
    Nickel nickel = new Nickel();
    Dime dime = new Dime();
    Quarter quarter = new Quarter();
    
    System.out.println("Value of penny "+penny.getValue() + "$");
    System.out.println("Value of nickel "+nickel.getValue()+"$");
    System.out.println("Value of dime "+dime.getValue()+"$");
    System.out.println("Value of quarter "+quarter.getValue()+"$");
    
    Scanner myScanner = new Scanner(System.in); // create scanner object for input
    PiggyBank bank = new PiggyBank(); // create an new PiggyBank object.
    ArrayList<String> coins = new ArrayList<String>();
    int size = coins.size();
    
    int choice;
    do {
      System.out.println("1. Show total in bank.");
      System.out.println("2. Add a penny.");
      System.out.println("3. Add a nickel.");
      System.out.println("4. Add a dime.");
      System.out.println("5. Add a quarter.");
      System.out.println("6. Take money out of the bank.");
      System.out.println("Enter 0 to quit.");
      System.out.print("Enter your choice:");
      choice = myScanner.nextInt();
      
      if (choice == 1) {
        System.out.println("Total amount in bank: $" + bank.getTotal());
        for (int i = 0; i < coins.size(); i++)
        {
          String item = coins.get(i);
          System.out.println("Item " + (i+1) + " : " + item);
        }
      } else if (choice == 2) {
        bank.addPenny();
        coins.add("Penny "+penny.getValue() + "$");
      } else if (choice == 3) {
        bank.addNickel();
         coins.add("Nickel "+nickel.getValue() + "$");
      } else if (choice == 4) {
        bank.addDime();
         coins.add("Dime "+dime.getValue() + "$");
      } else if (choice == 5) {
        bank.addQuarter();
         coins.add("Quarter "+quarter.getValue() + "$");
      } else if (choice == 6) {
        System.out.print("Enter amount to remove: $");
        double amount = myScanner.nextDouble();
        double amountRemoved = bank.removeAmount(amount);
        System.out.println("You removed: $ " + amountRemoved);
      }      
    } while (choice != 0);
    
    System.out.println("Thanks for using the MySavings Application.");
    myScanner.close();
  }
  
}