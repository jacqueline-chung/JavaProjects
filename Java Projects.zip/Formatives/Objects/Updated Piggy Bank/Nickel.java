public class Nickel extends Coin{
  public double getValue(){
    //System.out.println("Nickel: 0.05$");
    return 0.05;
  }
}