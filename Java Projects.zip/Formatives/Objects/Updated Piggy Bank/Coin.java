public abstract class Coin{
  //define behaviour
  public abstract double getValue();
}