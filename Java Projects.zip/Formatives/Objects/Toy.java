public class Toy {
  String name;
  double cost;
  double sellingPrice;
  
  public Toy() { //initialize info
    name = "Toy 1";
    cost = 0;
    sellingPrice = 0;
  }
  
  public Toy(String toyName, double toyCost, double toySellingPrice) { //take in info
    name = toyName;
    cost = toyCost;
    sellingPrice = toySellingPrice;
  }
  
  public String getName() {
    return name; 
  }
  
  public double getCost() {
    return cost; 
  }
  
  public double getSellingPrice() {
    return sellingPrice; 
  }
  //mmodifier methods, setter methods
  public void setName(String n) {
    name = n; 
  }
  
  public void setCost(double c) {
    cost = c; 
  }
  
  public void setSellingPrice(double s) {
    sellingPrice = s; 
  }
}

