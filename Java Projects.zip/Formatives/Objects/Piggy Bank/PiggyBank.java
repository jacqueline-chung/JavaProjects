public class PiggyBank {
 
    public double savings;
 
    //Constructor
    public PiggyBank(){
        savings = 0.00;
    }//End of constructor
 
    public double addPenny( ) {
        this.savings += 0.01;
        return savings;
        //Display output.
    }//End of set
 
    public double addNickel() {
        savings = savings + 0.05;
        return savings;
 
        //Display output.
    }//End of set
 
    public double addDime() {
        savings = savings + 0.10;
        return savings;
 
    }//End of set
 
    public double addQuarter() {
        savings = savings + 0.25;
        return savings;
 
    }//End of set
 
    //METHOD: Get the current of the radius
    public double getSavings() {
        return this.savings;
    }
 
}//End of PiggyBank