public abstract class Change {
 //define states of shape
  
  double balance;
  
  public Change(){
   this.balance = 0.00; 
  }
  
  //define behaviour
  public abstract double penny();
  public abstract double nickel();
  public abstract double dime();
  public abstract double quarter();
  public abstract void draw();
}