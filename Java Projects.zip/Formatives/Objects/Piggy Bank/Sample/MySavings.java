import java.util.Scanner;
/**
 * Name: Mrs. Andrighetti
 * Date: December 15, 2015
 * Description:  MySavings appliction.  Will provide menu functionality for 
 *               saving money in a PiggyBank
 */
public class MySavings {
  
  /**
   * main method -- menu driven application for storing money in a piggy bank
   */
  public static void main(String[] args) { 
    Scanner myScanner = new Scanner(System.in); // create scanner object for input
    PiggyBank bank = new PiggyBank(); // create an new PiggyBank object.
    
    int choice;
    do {
      System.out.println("1. Show total in bank.");
      System.out.println("2. Add a penny.");
      System.out.println("3. Add a nickel.");
      System.out.println("4. Add a dime.");
      System.out.println("5. Add a quarter.");
      System.out.println("6. Take money out of the bank.");
      System.out.println("Enter 0 to quit.");
      System.out.print("Enter your choice:");
      choice = myScanner.nextInt();
      
      if (choice == 1) {
        System.out.println("Total amount in bank: $" + bank.getTotal());
      } else if (choice == 2) {
        bank.addPenny();
      } else if (choice == 3) {
        bank.addNickel();
      } else if (choice == 4) {
        bank.addDime();
      } else if (choice == 5) {
        bank.addQuarter();
      } else if (choice == 6) {
        System.out.print("Enter amount to remove: $");
        double amount = myScanner.nextDouble();
        
        double amountRemoved = bank.removeAmount(amount);
        System.out.println("You removed: $ " + amountRemoved);
      }      
    } while (choice != 0);
    
    System.out.println("Thanks for using the MySavings Application.");
    myScanner.close();
  }
}