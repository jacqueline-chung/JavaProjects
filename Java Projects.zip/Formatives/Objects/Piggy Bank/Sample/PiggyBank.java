/**
 * Name: Mrs. Andrighetti
 * Date: December 15, 2015
 * Description:  PiggyBank class.  This class stores an amount that is saved by adding
 *               coins to the object.
 */
public class PiggyBank {
  // class constants
  public static final double PENNY = 0.01;
  public static final double NICKEL = 0.05;
  public static final double DIME = 0.10;
  public static final double QUARTER = 0.25;
  
  private double total;  // total amount in piggy bank
  
  public PiggyBank() {
    total = 0;
  }
  
  public PiggyBank(double startingAmount) {
    total = startingAmount;
  }
  
  // methods
  public void addPenny() {
    total += PENNY;
  }
  
  public void addNickel() {
    total += NICKEL;
  }
  
  public void addDime () {
    total += DIME;
  }
  
  public void addQuarter() {
    total += QUARTER;
  }
  
  public double removeAmount(double amount) {
    double amountRemoved = amount;
    if (amount < total) {
      total -= amount;
    } else {
      amountRemoved = total;
      total = 0;
    }
    return amountRemoved;
  }
  
  // accessor methods
  public double getTotal() {
    return total;
  }
  
}