public class AnimalApp {
  
  public AnimalApp() { 
  }
  
  public static void main(String[] args) { 
    //create toy object
    Animal frog = new Animal("Frog", "", "", "", "");
    System.out.println("My animal name is " + frog.getName());
    
//    connect4.setName("Connect Four");
//    System.out.println("My toy name is " + connect4.getName());
  }
}
