public class Animal {
  String name;
  String diet;
  String type;
  String size;
  String habitat;
  
  // initialize your class variables
  public Animal() {
    name = "animal 1";
    diet = "meat or vegan";
    type = "mammal or reptile or fish";
    size = "big or small";
    habitat = "land or sea";
  }
  
  public Animal(String animalName, String animalDiet, String animalType, String animalSize, String animalHabitat) {
    name = animalName;
    diet = animalDiet;
    type = animalType;
    size = animalSize;
    habitat = animalHabitat;
  }
  
  // accessor methods
  public String getName() {
    return name;
  }
  
  public String getDiet() {
    return diet;
  }
  
  
  public String getType() {
    return type;
  }
  
  public String getSize() {
    return size;
  }
  
  public String getHabitat() {
    return habitat;
  }
  
//  public double getNewSellingPrice() {
//    newSellingPrice = 15.00;
//    return newSellingPrice;
//  }
  
  // modifier methods
  public void setName(String n) {
    name = n;
  }
  
  public void setDiet(String d) {
    diet = d;
  }
  
  public void setType(String t) {
    type = t;
    //newCost = 2.00;
  }
  
  public void setSize(String s) {
    size = s;
  }
  
  public void setHabitat(String h) {
    habitat = h;
  }
  
  
//  public double getNewProfit(){//returns the profit for the object Toy
//    newProfit= newSellingPrice-newCost;
//    return newProfit;
//  }
  
}