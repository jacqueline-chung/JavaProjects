//Subtype the Coin class to create a Quarter class
public class Quarter extends Coin {
  //accessor method 
  public double getValue() {
    return 0.25; //return value of quarter
  }
}


