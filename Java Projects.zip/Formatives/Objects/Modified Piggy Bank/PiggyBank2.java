/* Name: Jacqueline Chung
 * Teacher: Mrs. Andrighetti
 * Date: January 6, 2015
 * Description:  PiggyBank2 class.  This class stores an amount that is saved by adding coins to the object.
 * PiggyBank2 should now contain a list of Coin�s, to represent what is actually stored in the piggy bank.
 * Update the PiggyBank2 so that it functions the same as before � except it will use the new list of Coins.
*/

public class PiggyBank2 {
  // class constants
  public static final double PENNY = 0.01;
  public static final double NICKEL = 0.05;
  public static final double DIME = 0.10;
  public static final double QUARTER = 0.25;
  
  private double total;  // declare total amount in piggy bank
  
  //constructor
  public PiggyBank2() { 
    total = 0; //set total to 0
  }
  
  public PiggyBank2(double startingAmount) {
    total = startingAmount; //set total as the value passed (startingAmount)
  }
  
  // methods
  public void addPenny() { //add penny when user chooses 2
    total += PENNY; //add to total in piggy bank
  }
  
  public void addNickel() { //add nickel when user chooses 3
    total += NICKEL;//add to total in piggy bank
  }
  
  public void addDime () { //add dime when user chooses 4
    total += DIME;//add to total in piggy bank
  }
  
  public void addQuarter() { //add quarter when user chooses 5
    total += QUARTER; //add to total in piggy bank
  }
  
  public void removeCoins(double amount) { //remove coins when user chooses 6
    total -= amount; //remove from total
  }
  
  // accessor methods getTotal to return the total in the bank
  public double getTotal() {
    return total; //return total value in piggybank
  }
}