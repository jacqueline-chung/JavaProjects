/* Name: Jacqueline Chung
 * Teacher: Mrs. Andrighetti
 * Date: January 6, 2015
 * Description:  Create a MySavings2 application that displays a menu of choices for entering pennies, nickels, dimes, 
 * and quarters into a piggy bank and then prompts the user to make a selection.  
 * The MySavings2 application should include a PiggyBank2 object that can add coins to the piggy bank, 
 * remove coins, and return the total amount in the bank.
 */

//declare imports 
import java.util.ArrayList;
import java.util.Scanner;

public class MySavings {
  public static void main(String[] args) {  //main method -- menu driven application for storing money in a piggy bank
    ArrayList<Object> coins = new ArrayList<Object>(); // Create an ArrayList that holds references to String
    
    Scanner myScanner = new Scanner(System.in); // create scanner object for input
    PiggyBank bank = new PiggyBank(); // create an new PiggyBank object.
    
    double choice; //declare variable for user input choice, double -  in case user types in dollar amount
    
    //create objects for each coin
    Penny p = new Penny();
    Nickel n = new Nickel();
    Dime d = new Dime();
    Quarter q = new Quarter();
    
    int pcount = 0, ncount = 0, dcount = 0, qcount = 0; //declare counters for coins
    
    //print values of all the coins to test getValue
    System.out.println("Value of penny: " + p.getValue());
    System.out.println("Value of nickel: " + n.getValue());
    System.out.println("Value of dime: " + d.getValue() + "0");
    System.out.println("Value of quarter: " + q.getValue());
    
    do {
      //print choices user can pick
      System.out.println("1. Show total in bank.");
      System.out.println("2. Add a penny.");
      System.out.println("3. Add a nickel.");
      System.out.println("4. Add a dime.");
      System.out.println("5. Add a quarter.");
      System.out.println("6. Take money out of the bank.");
      System.out.println("Enter 0 to quit.");
      
      System.out.print("Enter your choice:"); //prompt user to choose
      choice = myScanner.nextInt(); //receive and store value
      
      if (choice == 1) { //if user chooses 1 - shows total amount in PiggyBank
        //print summary, the number of coins
        System.out.println("Summary: ");
        System.out.println("# of Pennies: " + pcount);
        System.out.println("# of Nickels: " + ncount);
        System.out.println("# of Dimes: " + dcount);
        System.out.println("# of Quarters: " + qcount);
        
        //loop to print all the trasnactions made
        for (int i = 0; i < coins.size(); i++) {
          System.out.println("Transaction #" + (i+1) + ": " +((Coin)coins.get(i)).getValue()); //print transactions
        }
        
        double total = Math.round(bank.getTotal() * 100); //round total to 2 decimal places
        System.out.println("TOTAL amount in Piggy Bank: $" + total/100); //print total in piggybank
        
      } else if (choice == 2) { //if user chooses 2 - add pennies
        bank.addPenny(); //add penny to bank
        coins.add(p); //add value of penny to arraylist
        System.out.println("Added Penny"); //print message that a coin was added
        pcount++; //add to counter
      } else if (choice == 3) { //if user chooses 3 - add nickels
        bank.addNickel(); //add nickel to bank
        coins.add(n); //add value of nickel to arraylist
        System.out.println("Added Nickel"); //print message that a coin was added
        ncount++; //add to counter
      } else if (choice == 4) { //if user chooses 4 - add dimes
        bank.addDime(); //add dime to bank
        coins.add(d); //add value of quarter to arraylist
        System.out.println("Added Dime"); //print message that a coin was added
        dcount++; //add to counter
      } else if (choice == 5) { //if user chooses 5 - add quarters
        bank.addQuarter(); //add quarter to bank
        coins.add(q); //add value of quarter to arraylist
        System.out.println("Added Quarter"); //print message that a coin was added
        qcount++; //add to counter
      } else if (choice == 6) { //if user chooses 6 to remove amount in bank       
        if (coins.isEmpty()) { //if the coins arraylist is empty
          System.out.println("Piggy bank is empty!"); //print message that the bank is empty
          
        } else {
          System.out.print("Enter amount to remove: $"); //prompt user to enter amount to remove
          double amount = myScanner.nextDouble(); //get input from user and store amount
   
          if(amount >= bank.getTotal()){  //if amount requested is greater the bank total          
            double total = Math.round(bank.getTotal() * 100); //round total to 2 decimal places
            System.out.println("Your request is greater than the amount in the PiggyBank, the total removed::" + total/100);
            
            //remove all the coins in the PiggyBank, reset all the counters
            coins.clear();             
            pcount = 0;            
            ncount = 0;            
            dcount = 0;            
            qcount=0; 
            bank.removeCoins(bank.getTotal());
            
          } else {  
            double remove = 0; //declare remove variable 
            
            for (int i = 0; i < coins.size(); i++) { //loop through arraylist
              while(remove < amount) {   //while remove amount is less than the amount requested             
                remove = remove + ((Coin)coins.get(i)).getValue(); //add each coins until remove is greater tha amount               
                coins.remove(i); //remove the cons reduced from remove
                
                System.out.println("TRANSACTIONS: Removed "+ remove); //print all the removal transactions

                //for each coin, print the what was removed, decreasing the counters by 1 each time
                if(((Coin)coins.get(i)).getValue() == 0.01) {                  
                  System.out.println("Removed penny");                  
                  pcount--;                  
                } else if(((Coin)coins.get(i)).getValue() == 0.05) {                  
                  System.out.println("Removed nickel");                  
                  ncount--;                  
                } else if (((Coin)coins.get(i)).getValue() == 0.1) {
                  System.out.println("Removed dime");
                  dcount--;
                } else if (((Coin)coins.get(i)).getValue() == 0.25) {
                  System.out.println("Removed quarter");
                  qcount--;
                }
              }
            }
            bank.removeCoins(remove); //remove the coins in piggy bank
          }        
        }      
      } else {
        System.out.println("Please enter a valid choice"); //data validation
      }
    } while (choice != 0);
    System.out.println("Thanks for using the MySavings Application."); //print message to thank the user for using the program 
    myScanner.close();
  } //end main method
}//end class