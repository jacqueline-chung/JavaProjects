import java.util.Scanner;

import java.util.ArrayList; 

/**
 * 
 * Name: Lisa Zaprudskaya
 * 
 * Date: January 4th, 2016
 * 
 * Description:  MySavings appliction.  Will provide menu functionality for 
 * 
 *               saving money in a PiggyBank
 * 
 */

public class MySavings_Lisa {//class
  
  
  
  /**
   * 
   * main method -- menu driven application for storing money in a piggy bank
   * 
   */
  
  public static void main(String[] args) { //main class
    
    
    
    //initialize new objects
    
    Penny penny = new Penny();
    
    Nickel nickel = new Nickel();
    
    Dime dime = new Dime();
    
    Quarter quarter = new Quarter();
    
    
    
    //display values of each coin
    
    System.out.println("Value of penny "+penny.getValue() + "$");
    
    System.out.println("Value of nickel "+nickel.getValue()+"$");
    
    System.out.println("Value of dime "+dime.getValue()+"$");
    
    System.out.println("Value of quarter "+quarter.getValue()+"$");
    
    
    
    //declare scanner
    
    Scanner myScanner = new Scanner(System.in); // create scanner object for input
    
    
    
    //create a piggy bank
    
    PiggyBank bank = new PiggyBank(); // create an new PiggyBank object.
    
    
    
    //create a double list of coins array
    
    ArrayList<Object> coins = new ArrayList<Object>();
    
    
    
    //size of array
    
    //int size = coins.size();
    
    
    
    //counters for each coin value
    
    int pennyCOUNTER=0;
    
    int nickelCOUNTER=0;
    
    int dimeCOUNTER=0;
    
    int quarterCOUNTER=0;
    
    
    
    //user input variable
    
    double choice;//double in case user acciedetly enters a decimal, preventing program from crashing
    
    
    
    //display options
    
    do {
      
      System.out.println("1. Show total in bank.");
      
      System.out.println("2. Add a penny.");
      
      System.out.println("3. Add a nickel.");
      
      System.out.println("4. Add a dime.");
      
      System.out.println("5. Add a quarter.");
      
      System.out.println("6. Take money out of the bank.");
      
      System.out.println("Enter 0 to quit.");
      
      System.out.print("Enter your choice:");
      
      choice = myScanner.nextDouble();//user input
      
      
      
////////////***User selected: ***\\\\\\\\\\\\      
      
      if (choice == 1) {
        
        System.out.println("SUMMARY");
        
        System.out.println("# of Pennies: "+ pennyCOUNTER);
        
        System.out.println("# of Nickels: "+ nickelCOUNTER);
        
        System.out.println("# of Dimes: "+ dimeCOUNTER);
        
        System.out.println("# of Quarters: "+ quarterCOUNTER + "\n");
        
//        System.out.println("TRANSACTIONS");
        
//        for (int i = 0; i < coins.size(); i++)
        
//        {
        
//          Double item = coins.get(i);
        
//          System.out.println("Transaction #" + (i+1) + " : " + item);
        
//        }
        
        System.out.println("\n"+ "TOTAL");
        
        System.out.println("Total amount in bank: $" + bank.getTotal()+ "\n");
        
      } else if (choice == 2) {
        
        pennyCOUNTER++;
        
        bank.addPenny();
        
        coins.add(penny);
        
      } else if (choice == 3) {
        
        nickelCOUNTER++;
        
        bank.addNickel();
        
        coins.add(nickel);
        
      } else if (choice == 4) {
        
        dimeCOUNTER++;
        
        bank.addDime();
        
        coins.add(dime);
        
      } else if (choice == 5) {
        
        quarterCOUNTER++;
        
        bank.addQuarter();
        
        coins.add(quarter);
        
      } else if (choice == 6) {
        
        
        
        if(coins.isEmpty()) {
          
          System.out.println("Piggy bank empty");
          
        }else {
          
          System.out.print("Enter amount to remove:");
          
          double amount = myScanner.nextDouble();
          
          
          
          if(amount >= bank.getTotal()) {
            
            System.out.println("Requested amount too much, can only remove:" + bank.getTotal());
            
            coins.clear(); 
            
            pennyCOUNTER=0;
            
            nickelCOUNTER=0;
            
            dimeCOUNTER=0;
            
            quarterCOUNTER=0;
            
            bank.removeCoins(bank.getTotal());
            
            
            
          }else {
            
            double remove=0;
            
            for (int i = 0; i < coins.size(); i++){
              
              while(remove<amount){
                
                remove=remove+((Coin)coins.get(i)).getValue();
                
                coins.remove(i);
                
                
                
                
                
                if(((Coin)coins.get(i)).getValue()==0.01){
                  
                  System.out.println("Removed penny");
                  
                  pennyCOUNTER--;
                  
                }else if(((Coin)coins.get(i)).getValue()==0.05){
                  
                  System.out.println("Removed nickel");
                  
                  nickelCOUNTER--;
                  
                } else if(((Coin)coins.get(i)).getValue()==0.1){
                  
                  System.out.println("Removed dime");
                  
                  dimeCOUNTER--;
                  
                }else if(((Coin)coins.get(i)).getValue()==0.25){
                  
                  System.out.println("Removed quarter");
                  
                  quarterCOUNTER--;
                  
                }
                System.out.println("Transaction: Total Removed "+ remove);
                
              }
              
            }
            
            bank.removeCoins(remove);
            
          }        
          
        }      
        
      }else {
        
        System.out.println("Please enter a valid choice");
        
      }
      
    } while (choice != 0);
    
    System.out.println("Thanks for using the MySavings Application.");
    
    myScanner.close();
    
  }
  
}