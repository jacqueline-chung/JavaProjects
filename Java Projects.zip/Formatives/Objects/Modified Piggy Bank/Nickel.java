//Subtype the Coin class to create a Nickel class
public class Nickel extends Coin {
  //accessor method
  public double getValue() {
    return 0.05; //return value of nickel
  }
}


