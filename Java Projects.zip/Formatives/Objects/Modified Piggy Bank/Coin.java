//Subtype the Coin class to create a Penny, Dime, Nickel, and Quarter class.
public abstract class Coin {
  //define behaviour
  public abstract double getValue(); //declare accessor method getValue in abstract class
}