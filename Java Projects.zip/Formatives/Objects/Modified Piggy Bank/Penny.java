//Subtype the Coin class to create a Penny class
public class Penny extends Coin {
  //accessor method
  public double getValue() {
    return 0.01; //return value of penny
  }
}


