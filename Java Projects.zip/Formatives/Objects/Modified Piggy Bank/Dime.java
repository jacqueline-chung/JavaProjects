//Subtype the Coin class to create a Dime class
public class Dime extends Coin {
  //accesor methods
  public double getValue() { 
    return 0.10; //return dime value
  }
}


