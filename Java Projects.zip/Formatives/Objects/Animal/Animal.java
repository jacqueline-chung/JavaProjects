/*
 */

public class Animal 
{
  public static final char MALE = 'M';
  public static final char FEMALE = 'F';
  
  // attributes of an animal
  private String name;
  private double height; // height in inches
  private double weight; // weight in lbs
  private String colour;
  private char gender;
    
  /**
   * Default constructor - initializes class attributes to default values
   */
  public Animal() {
    name = "animal";
    height = 0;
    weight = 0;
    colour = "black";
    gender = FEMALE;
    
  }
  
  /**
   * Constructor - initializes class attributes to values passed in the parameter list
   */
  public Animal(String animalName, double animalHeight, double animalWeight, String animalColour, char animalGender) {
    name = animalName;
    height = animalHeight;
    animalWeight = animalWeight;
    colour = animalColour;
    gender = animalGender;
    
  }
  
  //****** accessor methods -- getter methods
  public String getName() { 
    return name; 
  }
  
  public double getHeight() {
    return height;
  }
  
  public double getWeight() {
    return weight;
  }
  
  public String getColour() {
    return colour;
  }
  
  public char getGender() {
    return gender;
  }
  
  //******* accessor methods -- setter methods
  public void setName(String n) {
    name = n;
  }
  
  public void setHeight(double h) {
    height = h;
  }
  
  public void setWeight(double w) {
    weight = w;
  }
  
  public void setColour(String c) {
    colour = c;
  }
  
  public void setGender(char g) {
    gender = g;
  }
  
  public void hunt(Animal a) {
    System.out.println(name + " is hunting with " + a.getName());
  }
  
  public boolean isMale() {
    if (gender == MALE) {
      return true;
    }
    return false;
  }
}