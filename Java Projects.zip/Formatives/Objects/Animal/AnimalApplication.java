///**
// * Auto Generated Java Class.
// */
//public class AnimalApplication {
//  
//  
//  public static void main(String[] args) { 
////    SuperAnimal sAnimal1 = new SuperAnimal(); // sets all the attributes of sAnimal1 to defaults
//    Animal sAnimal1 = new Animal(); // sets all the attributes of sAnimal1 to defaults
//    
//    System.out.println(sAnimal1.getName());
//    System.out.println(sAnimal1.gender);
//    System.out.println(sAnimal1.fly());
//    
//    
////    SuperAnimal cat = new SuperAnimal("cat", 12, 10.2, "grey", Animal.MALE, true, false);
//    Animal cat = new Animal("cat", 12, 10.2, "grey", Animal.MALE, true, false);
//    System.out.println(cat.getName());
//    System.out.println(cat.getGender());
//    System.out.println(cat.fly());
//  }
////}