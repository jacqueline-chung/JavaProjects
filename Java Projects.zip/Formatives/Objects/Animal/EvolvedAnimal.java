//public class EvolvedAnimal extends Animal 
//{
//  private boolean hasWings;
//  private boolean canTeleport;
//  
//  public EvolvedAnimal() {
//    super();
//    hasWings = false;
//    canTeleport = false;
//  }
//  
//  public EvolvedAnimal(String animalName, double animalHeight, double animalWeight, String animalColour, 
//                     char animalGender, boolean animalWings, boolean animalCanTeleport) {
//    super(animalName, animalHeight, animalWeight, animalColour, animalGender);
//    hasWings = animalWings;
//    canTeleport = animalCanTeleport;
//  }
//  
//  // methods
//  public String fly() {
//    String message = getName() + " cannot fly.";
//    if (hasWings) {
//      message = getName() + " can fly.";
//    }
//    return message;
//  }
//  
//  public String teleport(String toPlace) {
//    String message = name + " cannot teleport.";
//    if (canTeleport) {
//      message = getName() + " is teleporting to " + toPlace;
//    }
//    return message;
//  }
//  
//}