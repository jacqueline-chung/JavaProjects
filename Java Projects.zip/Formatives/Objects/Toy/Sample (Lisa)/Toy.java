public class Toy {
  String name;
  double cost;
  double sellingPrice;
  double profit;
  double newSellingPrice;
  double newCost;
  double newProfit;
  
  // initialize your class variables
  public Toy() {
    name = "toy 1";
    cost = 0;
    sellingPrice = 0;
    newSellingPrice=0;
    newCost=0;
  }
  
  public Toy(String toyName, double toyCost, double toySellingPrice) {
    name = toyName;
    cost = toyCost;
    sellingPrice = toySellingPrice;
  }
  
  // accessor methods
  public String getName() {
    return name;
  }
  
  public double getCost() {
    return cost;
  }
  
  
  public double getSellingPrice() {
    return sellingPrice;
  }
  
  public double getNewSellingPrice() {
    newSellingPrice = 15.00;
    return newSellingPrice;
  }
  
  // modifier methods
  public void setName(String n) {
    name = n;
  }
  
  public void setCost(double c) {
    cost = c;
  }
  
  public void setNewCost() {
    newCost = 2.00;
  }
  
  public double getNewCost() {
    return newCost=2;
  }
  
  public void setSellingPrice(double sp) {
    sellingPrice = sp;
  }
  
  public double getProfit(){//returns the profit for the object Toy
    profit=sellingPrice-cost;
    return profit;
  }
  
  public double getNewProfit(){//returns the profit for the object Toy
    newProfit= newSellingPrice-newCost;
    return newProfit;
  }
  
}