/**
 * Auto Generated Java Class.
 */
public class ToyApplication {
  
  
  public static void main(String[] args) { 
    // create a toy object
    Toy connect4 = new Toy("Connect 4", 2.25, 11.99);
    
    System.out.println("My toy name is " + connect4.getName());
    System.out.println("Cost To Make: "+ connect4.getCost());
    System.out.println("Selling Price: "+ connect4.getSellingPrice());
    System.out.println("Profit: " + connect4.getProfit());
    System.out.println("New Cost To Make: "+ connect4.getNewCost());
    System.out.println("New Selling Price: "+ connect4.getNewSellingPrice());
    System.out.println("New Profit: " + connect4.getNewProfit());
    
    
    connect4.setName("Connect Four");
    
    System.out.println("\nMy toy name is " + connect4.getName());
    System.out.println("Cost To Make: "+ connect4.getCost());
    System.out.println("Selling Price: "+ connect4.getSellingPrice());
    System.out.println("Profit: " + connect4.getProfit());
    
    Toy monopoly = new Toy ("Monopoly", 4.89, 19.99);
    
    System.out.println("\nMy toy name is " + monopoly.getName());
    System.out.println("Cost To Make: "+ monopoly.getCost());
    System.out.println("Selling Price: "+ monopoly.getSellingPrice());
    System.out.println("Profit: " + monopoly.getProfit());
    
    Toy[] myToys;
    
  }
  
  /* ADD YOUR CODE HERE */
  
}