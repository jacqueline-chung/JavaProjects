public class Toy {
  String name;
  double cost;
  double sellingPrice;
  double profit;
  
  public Toy() { //initialize info
    name = "Toy 1";
    cost = 0;
    sellingPrice = 0;
    profit = 0;
  }
  
  public Toy(String toyName, double toyCost, double toySellingPrice, double toyProfit) { //take in info
    name = toyName;
    cost = toyCost;
    sellingPrice = toySellingPrice;
    profit = toyProfit;
  }
  
  public String getName() {
    return name; 
  }
  
  public double getCost() {
    return cost; 
  }
  
  public double getSellingPrice() {
    return sellingPrice; 
  }
  
  public double getProfit() {
    profit = sellingPrice-cost;
    return profit; 
  }
  //mmodifier methods, setter methods
  public void setName(String n) {
    name = n; 
  }
  
  public void setCost(double c) {
    cost = c; 
  }
  
  public void setSellingPrice(double s) {
    sellingPrice = s; 
  }
  
  public void setProfit(double p) {
    
    profit = p; 
  }
}

