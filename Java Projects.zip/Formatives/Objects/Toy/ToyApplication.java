//public class ToyApplication {
//  
//  public ToyApplication() { 
//    /* YOUR CONSTRUCTOR CODE HERE*/
//  }
//  
//  public static void main(String[] args) { 
//    //create toy object
//    Toy connect4 = new Toy("Connect 4", 2.25, 11.99, 22.00);
//    System.out.println("My toy name is " + connect4.getName());
//    
//    connect4.setName("Connect Four");
//    System.out.println("My toy name is " + connect4.getName());
//    
//    Toy monopoly = new Toy ("Monopoly", 4.89, 19.99, 32.00);
//    System.out.println("My toy name is " + monopoly.getName());
//    
//    Toy chess = new Toy ("Chess", 6.89, 24.99, 36.00);
//    System.out.println("My toy name is " + chess.getName());
//    
//    Toy [] myToys; //create array of objects
//    
//    for (int i = 0; i < 4; i++) {
//      myToys[i] = getProfits();
//    }
//    
////    boolean swapped = true;
////    int j = 0;
////    int tmp;
////    while (swapped) {
////      swapped = false;
////      j++;
////      for (int i = 0; i < myToys.length - j; i++) {                                       
////        if (myToys[i] > myToys[i + 1]) {                          
////          tmp = myToys[i];
////          myToys[i] = myToys[i + 1];
////          myToys[i + 1] = tmp;
////          swapped = true;
////        }
////      }                
////    }
//  }
//}
