import java.util.Scanner;

class gcf {
  public static void main (String args[]) {
    Scanner myScanner = new Scanner(System.in);
    
    System.out.println("Enter a number");
    int num1 = myScanner.nextInt();
    
    System.out.println("Enter another number");
    int num2 = myScanner.nextInt();
    
    System.out.println("The GCF of " + num1 + " and " + num2 + " is " + gcf(num1, num2));
  }
  
  public static int gcf(int m, int n) {
    if (m > n) {
      return gcf(n, m - n);
    } else if (m < n) {
      return gcf(n, m);
    } else {
      return m;
    }
  }
}