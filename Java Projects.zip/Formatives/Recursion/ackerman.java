import java.util.Scanner;

class ackerman {
  public static void main (String args[]) {
    Scanner myScanner = new Scanner(System.in);
    
    System.out.println("Enter two integers");
    int x = myScanner.nextInt();
    int y = myScanner.nextInt();
    
    System.out.println(a(x, y));
  } 
  
  public static int a(int m, int n) {
    if (m == 0) {
      return n + 1;
    } else if (n == 0) {
      return a(m-1, 1);
    } else {
      return a(m - 1, a(m, n-1));
    }
  }
}