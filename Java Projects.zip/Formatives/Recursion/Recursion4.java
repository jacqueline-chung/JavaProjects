/* [Recursion4 .java]
 * Create a menu driven program that will run any procedure described below. Use only local variables.
 * Author: Jacqueline Chung
 * Date: October 15, 2015
 */

import java.util.Scanner;
class Recursion5 {
  public static void main(String args[]) {  //main method
    
    Scanner userInput = new Scanner(System.in);

    System.out.println("Enter a number of laughs");
    int num = userInput.nextInt();
    
    System.out.println(laughs(num));
  }
  
  public static String laughs(int n) {
    if (n <= 0) {
      return "no laughs";   
    } else {
      System.out.print("HA ");
      return laughs(n-1);
    }
  }
}