import java.util.Scanner;

class triangle {
  public static void main (String args[]) {
    Scanner myScanner = new Scanner(System.in);
    
    System.out.println("Enter number of rows");
    int num = myScanner.nextInt();
    
    System.out.print(triangle(num));
  }
  
  public static int triangle(int row) {
    if (row > 0) {
      return row + triangle(row - 1);
    } else {
      return 0;
    }
  }
}