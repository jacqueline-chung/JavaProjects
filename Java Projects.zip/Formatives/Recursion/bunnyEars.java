import java.util.Scanner;

class bunnyEars {
  public static void main (String args[]) {
    Scanner myScanner = new Scanner(System.in);
    
    System.out.println("Enter number of bunnies");
    int num = myScanner.nextInt();
    
    System.out.print(bunnyEars(num));
  }
  
  public static int bunnyEars(int bunnies) {
    if (bunnies > 0) {
      return 2 + bunnyEars(bunnies-1);
    } else {
      return 0; 
    }
  }
}
