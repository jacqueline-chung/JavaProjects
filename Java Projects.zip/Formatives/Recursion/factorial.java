import java.util.Scanner;

class factorial {
  public static void main (String args[]) {
    Scanner myScanner = new Scanner(System.in);
    
    System.out.println("Enter a positive integer value");
    int num = myScanner.nextInt();
    System.out.println("The factorial of " + num + " is " + factorial(num));
  }
  
  public static int factorial (int integer) {
    if (integer == 1 || integer == 1) {
      return 1;
    } else if (integer > 0) {
      return integer * factorial(integer - 1);
    } else {
      return 0;
    }
  }
}