/* [Recursion2 .java]
 * Create a menu driven program that will run any procedure described below. Use only local variables.
 * Author: Jacqueline Chung
 * Date: October 15, 2015
 */

import java.util.Scanner;
class Recursion2 {
  public static void main(String args[]) {  //main method
    
    Scanner userInput = new Scanner(System.in);
    
    int num1, num2;
    
    System.out.println("Enter one number");
    num1 = userInput.nextInt();
    
    System.out.println("Enter another number");
    num2 = userInput.nextInt();
    
    System.out.print("The gcf of " + num1 + " and " + num2 + " is " + gcf(num1, num2));
  }
  
  public static int gcf(int m, int n) {
    if (m > n) {
      return gcf (n, m-n);
    } else if (m < n) {
      return gcf(n, m);    
    } else {
      return m;
    }
  }
}