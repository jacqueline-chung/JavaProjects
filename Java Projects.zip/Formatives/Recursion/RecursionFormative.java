/* [RecursionFormative.java]
 * Create a menu driven program that will run any procedure described below. Use only local variables.
 * Author: Jacqueline Chung
 * Date: October 7, 2015
 */

import java.util.Scanner;
class RecursionFormative {
  public static void main(String args[]) {  //main method
    
    Scanner userInput = new Scanner(System.in);
    
    int value;
    
    System.out.println("Enter number");
    value = userInput.nextInt();
    
    System.out.print("The function is " + value + " is " + naturalFunction(value));
    
  }
  
  public static int naturalFunction(int n) {
    if (n == 1 || n == 2) 
    {
      return 1;
    } else {
      return naturalFunction (n - 1) + naturalFunction (n - 2);
    }
  }
}