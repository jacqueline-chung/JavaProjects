import java.util.Scanner;

class power {
  public static void main (String args[]) {
    Scanner myScanner = new Scanner(System.in);
    
    System.out.println("Enter base");
    double base = myScanner.nextInt();
    
    System.out.println("Enter power");
    double power = myScanner.nextInt();
    
    System.out.println("Result of base " + base + " to the power of " + power + " is " + powerValue(base, power));
  }
  
  public static double powerValue (double b, double p) {
    if (p > 0) {
      return b * powerValue(b, p - 1);
    } else if (p < 0) {
      return (1/b) * powerValue(b, p + 1);
    } else {
      return 1;
    }
  }
}