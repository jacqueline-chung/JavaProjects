import java.util.Scanner;

class bunnyEars {
  public static void main (int bunnies) {
    Scanner myScanner = new Scanner(System.in);
    
    System.out.println("Enter numbe rof bunny ears");
    int num = myScanner.nextInt();
    
    System.out.print(bunnyEars(num));
  }
  
  public int bunnyEars(int bunnies) {
    if (bunnies > 0) {
      return bunnies * bunnyEars(bunnies-1);
    } else {
      return 0; 
    }
  }
}
