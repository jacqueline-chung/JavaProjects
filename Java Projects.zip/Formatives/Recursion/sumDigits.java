import java.util.Scanner;

class sumDigits {
  public static void main (String args[]) {
    Scanner myScanner = new Scanner(System.in);
    
    System.out.println("Enter digit");
    int n = myScanner.nextInt();
    
    System.out.println(sumDigits(n));
  } 
  
  public static int sumDigits(int num) {
    if (num > 0) {
      return (num % 10) + sumDigits(num / 10);
    } else {
      return 0;
    }
  }
}