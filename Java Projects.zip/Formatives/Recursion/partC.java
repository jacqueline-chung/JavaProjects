import java.util.Scanner;

class partC {
  public static void main (String args[]) {
    Scanner myScanner = new Scanner(System.in);
    
    System.out.println("Enter n");
    double num = myScanner.nextInt();
    
    System.out.print(sequence(num));
  }
  
  public static double sequence(double n) {
    if (n > 1) {
      return 2 + sequence(n-1);
    } else if (n == 1) {
      return 1;
    } else {
      return 0;
    }
  }
}