import java.util.Scanner;

class fibonacii {
  public static void main (String args[]) {
    Scanner myScanner = new Scanner(System.in);
    
    System.out.println("Enter an integer");
    int n = myScanner.nextInt();
    
    System.out.println("Result of f(" + n + ") is " + fibonacii(n));
  } 
  
  public static int fibonacii(int integer) {
    if (integer < 1) {
      return integer;
    } else if (integer == 1 || integer == 2) {
      return 1;
    } else {
      return fibonacii(integer - 2) + fibonacii(integer - 1);
    }
  }
}