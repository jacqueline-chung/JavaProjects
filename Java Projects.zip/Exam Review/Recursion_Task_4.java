// The "Recursion_Task_4" class. June 15th, 2011

/*

    
Part A:
 Code a recursive method Power (      )that accepts 2  positive values, B and E and your method should 
 return the B raised to the value E. Examples:
     ie Power(2,3) would return the value 8
	Power(4,2) would return the value 16

Part B:       
  Prompt the user to enter two whole number values in the main method. Call the recursive 
	  method you wrote implement the function by passing the two values Base and Exponent and your function 
	  method (return type method) should compute and return the correct value. Output
	  the returned value in the main method.

*/


import java.awt.*;
import hsa.Console;

public class Recursion_Task_4
{
    static Console c;           // The output console
    
    public static void main (String[] args)
    {
	c = new Console ();
	
	// Place your program here.  'c' is the output console
    } // main method
} // Recursion_Task_4 class
