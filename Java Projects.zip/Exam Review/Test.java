/**
 * Auto Generated Java Class.
 */
public class Test {
  
  
  public static void main(String[] args) { 
    int x = 6;
    x = 23%5;
    System.out.println(x);
    if(x == 5) {
      
    }
  }
  
  /* ADD YOUR CODE HERE */
  
}
