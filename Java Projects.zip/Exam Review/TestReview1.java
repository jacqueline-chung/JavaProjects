// The "TestReview1" class.
/*
File: TestReview1.java
Author: Mr. J. Anandarajan
Date: June 16th, 2008
Description: To prepare class for test
*/

import java.awt.*;
import hsa.Console;

public class TestReview1
{
    static Console Con;           // The output console
    
    public static void main (String[] args)
    {
	Con = new Console ();
	
	int a, b, c, d, e, f, g, input;
	
	
	
	a = 5;
	
	b = 5;

	c = a++;// 
	
	// a = ?, b = , c = ,  d = no value
	
	
	
	
	
	
	
	
	
	
	d = ++b;//add 1 to b then store it to d
	
       // d = 6, b = 6
	
	Con.println("Please enter a value: ");
	
	input = Con.readInt();
	
	/* What are the values of a, b, c, and d at this point of the program
	
	a =
	    i)4
	    ii)5 (all)
	    iii)6
	    iv) 7
       
	    
	b =
	    i)4
	    ii)5 (all)
	    iii)6
	    iv) 7
	    
	c =
	
	     i)4
	    ii)5 
	    iii)6 (all)
	    iv) 7
	
	d =
	
	    i)4
	    ii)5 
	    iii)6 (1)
	    iv) 7
	
	*/
	
	Con.println("a        b        c       d");
	Con.println(a +"       "+b+"       "+c+"      "+d);
       /*
       
       
       
       
       */
	a =0;
	
	b = 20;

	a +=b;//means a = a+b
	
	c*=b; // means c = c*b
	
	  /* What are the values of
	
	a = 20
	
	b = 20
	
	c = 100
	
	input = a+b*c
	
	input =2020
	
	input = (a+b)*c
	
	input = 4000
	
	*/
	
	Con.println("Please enter a value: ");
	
	input = Con.readInt();
	
	Con.println("a        b        c");
	Con.println(a +"       "+b+"       "+c);
	
	// Place your program here.  'c' is the output console
    } // main method
} // TestReview1 class
