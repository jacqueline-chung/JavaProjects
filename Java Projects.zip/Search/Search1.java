/* Title: 
 * Description: 1. Prompt the user to enter 5 names and their respective phone numbers and store them in 
 * two arrays (name and phone array). Sort the names in alphabetical order and save it. 
 a) Prompt the user to enter a name to search in the array
 b) Find the name in the array using the sequential search method (write method)
 c) Find the name in the array using the non-recursive binary search method (write method)
 
 */ 
import java.util.Scanner;

public class Search1 {
  public static void main(String[] args) { 
    
    Scanner input = new Scanner(System.in);
    
    //declare variables
    String[] names = new String[5];
    int[] phoneNumbers = new int[5];
    boolean swapped = true;
    int j = 0, tempPh, min = 0, max = names.length - 1;
    String temp;
    
    System.out.println("Enter 5 names with phone numbers"); //prompt user 
    //get input from user
    for (int i = 0; i < names.length; i++) { 
      //store input from user
      names[i] = input.next();
      phoneNumbers[i] = input.nextInt();
    }
    
    while (swapped) { //while swapped is true
      swapped = false;
      
      j++;
      
      for (int i = 0; i < (names.length - j); i++) {        
        if (names[i].compareTo(names[i + 1]) > 0) {
          //swapped names
          temp = names[i];
          names[i] = names[i + 1]; 
          names[i + 1] = temp;
          //swapped phone numbers
          tempPh = phoneNumbers[i];
          phoneNumbers[i] = phoneNumbers[i + 1]; 
          phoneNumbers[i + 1] = tempPh;
          
          swapped = true; //set swapped true
        }
      }
    }
    
    for (int i = 0; i < names.length; i++) { //display new list
      System.out.println(names[i] + " " + phoneNumbers[i]);
    }
    
    System.out.println("Enter the name you want to search"); //prompt user 
    String sName = input.next(); //store input from user

    //System.out.println("Index (Non-Recursive Binary): " +  binarySearch(names, min, max, sName)); //prompt user 
   System.out.println("Index (Recursive Binary): " +  searchName(names, min, max, sName)); //prompt user
    //System.out.println("Index (Sequential): " +  sequentialSearch(names, sName)); //prompt user 
  }
  
  public static int binarySearch (String[] list, int low, int high, String sName) { 
    while (low <= high) {
      int mid = (high + low) / 2;
      if (list[mid].compareTo(sName) == 0) {
        return mid;
      } else if (list[mid].compareTo(sName) < 0) {
        high = mid - 1;
      } else {
        low = mid + 1;
      }
    }
    return -1;
  }
  
  public static int searchName(String[] list, int low, int high, String sName) { 
    if (low <= high) {
      
      int mid = (high + low) / 2;
      if (list[mid].compareTo(sName) == 0) {
        return mid;
      } else if (list[mid].compareTo(sName) > 0) {
        return searchName(list, low, mid - 1, sName) ;
      } else {
        return searchName(list, low, mid + 1, sName);
      }     
    } else {
      return -1;
    }
  }
  
  public static int sequentialSearch (String[] list, String name) { 
    for (int i = 0; i < list.length; i++) {  
      if (list[i].compareTo(name) == 0) {
        return i;      
      }
    }
    return -1;
  }
}